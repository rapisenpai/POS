
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import Dashboard.dashboard;
import confirmDialog.close;
import confirmDialog.serverIsNotConnected;

import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class login {

	JFrame logInFrame;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.logInFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
	 * Create the application.
	 */
	public login() {
		initialize();
		centreWindow(logInFrame);
		Connect();
		
	}
	String username;
	String password;
	public login(String username, String password) {
		initialize();
		centreWindow(logInFrame);
		Connect();
		this.username = username;
		this.password = password;
		txtUsername.setText(username);
		txtPassword.setText(password);
		
	}
	
	
	/*=====================================================================DATABASE LOGIN=======================================================*/
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
	public void Connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hospitalmanagementsystem", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, e);
			serverIsNotConnected.main(null);
		}
	}

	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		logInFrame = new JFrame();
		logInFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(login.class.getResource("/images/logo.jpg")));
		logInFrame.setBounds(100, 100, 450, 300);
		logInFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		logInFrame.setUndecorated(true); // <-- the title bar is removed here
		logInFrame.setResizable(false);
		logInFrame.setSize(865, 560);
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combo box
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
		
		logInFrame.getContentPane().setLayout(null);
		
		
		
		
		JPanel leftPanel = new JPanel();
		leftPanel.setBorder(null);
		leftPanel.setBackground(new Color(0xECF5FA));
		leftPanel.setBounds(0, 0, 501, 560);
		logInFrame.getContentPane().add(leftPanel);
		leftPanel.setLayout(null);
		
		

		JLabel eye = new JLabel("");
		
		eye.setHorizontalAlignment(SwingConstants.CENTER);
		eye.setIcon(new ImageIcon(login.class.getResource("/images/eye.png")));
		eye.setBounds(387, 285, 34, 38);
		leftPanel.add(eye);
		
		JLabel invisible = new JLabel("");
		invisible.setIcon(new ImageIcon(login.class.getResource("/images/invisible.png")));
		invisible.setHorizontalAlignment(SwingConstants.CENTER);
		invisible.setBounds(387, 285, 34, 38);
		leftPanel.add(invisible);
		
		
		invisible.setVisible(true);
		eye.setVisible(false);
		
		JLabel title = new JLabel("Get Started!");
		title.setForeground(new Color(0x1E3C72));
		title.setBounds(77, 99, 186, 38);
		title.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 30));
		leftPanel.add(title);
		
		JLabel loginFailedMessage = new JLabel("Incorrect password and username. Please try again.");
		loginFailedMessage.setHorizontalAlignment(SwingConstants.CENTER);
		loginFailedMessage.setFont(new Font("Euclid Circular A", Font.PLAIN, 14));
		loginFailedMessage.setForeground(Color.RED);
		loginFailedMessage.setBounds(77, 452, 352, 19);
		loginFailedMessage.setVisible(false);
		leftPanel.add(loginFailedMessage);

		
		txtUsername = new JTextField();
		txtUsername.setForeground(Color.BLACK);
		txtUsername.setBackground(Color.WHITE);
		txtUsername.setBorder(null);
		txtUsername.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		txtUsername.setBounds(77, 206, 352, 38);
		leftPanel.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel labelUsername = new JLabel("Username :");
		labelUsername.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelUsername.setBounds(77, 176, 122, 19);
		leftPanel.add(labelUsername);
		
		JLabel labelPassword = new JLabel("Password :");
		labelPassword.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword.setBounds(77, 255, 122, 19);
		leftPanel.add(labelPassword);
		
		
		JButton btnSignUp = new JButton("");
		btnSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
			}
		});
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signup2.main(null);
				logInFrame.setVisible(false);
				
			}
		});
		btnSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnSignUp.setIcon(new ImageIcon(login.class.getResource("/images/btnSignUp.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnSignUp.setIcon(new ImageIcon(login.class.getResource("/images/btnSignUp2.png")));
				
			}
		});
		btnSignUp.setIcon(new ImageIcon(login.class.getResource("/images/btnSignUp2.png")));
		btnSignUp.setOpaque(false);
		btnSignUp.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		btnSignUp.setContentAreaFilled(false);
		btnSignUp.setBorderPainted(false);
		btnSignUp.setBackground(new Color(0, 0, 0, 0));
		btnSignUp.setBounds(77, 408, 352, 40);
		leftPanel.add(btnSignUp);
		
		
		JButton btnLogin = new JButton("");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnLogin.setIcon(new ImageIcon(login.class.getResource("/images/btnLogin3.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnLogin.setIcon(new ImageIcon(login.class.getResource("/images/btnLogin4.png")));
				
			}
		});
		btnLogin.setBackground(new Color(0,0,0,0));
		btnLogin.setBorderPainted(false); 
		btnLogin.setContentAreaFilled(false);
		btnLogin.setOpaque(false);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
/*=====================================================================TEST LOGIN=======================================================*/
				
				String username = txtUsername.getText();
				String password = new String(txtPassword.getPassword());
				
				if (password.contains("password") && username.contains("username")) {
					dashboard.main(null);
					logInFrame.setVisible(false);
				}
				else {
					loginFailedMessage.setVisible(true);
					
				}
				
/*=====================================================================DATABASE LOGIN=======================================================*/				
				String companyId;
				
				try {
						pst = con.prepareStatement("SELECT * FROM login");
						rs = pst.executeQuery();
							while(rs.next()) {
								companyId = rs.getString("id");
								String username1 = rs.getString("username");
								String password1 = rs.getString("password");
								
										if (username.equals(username1) && (password.equals(password1))) {
											
											try {
												pst = con.prepareStatement("SELECT * FROM hospitalstaffs");
												rs = pst.executeQuery();
													while(rs.next()) {
														String id = rs.getString("id");
														String firstName = rs.getString("firstname");
														String lastName = rs.getString("lastname");
														String fullname = "Hello, "+ firstName + " " + lastName;
																if (companyId.equals(id)) {
																	logInFrame.setVisible(false);
																	new dashboard(fullname, id).mainFrame.setVisible(true);	
																	}
															}
											} catch (SQLException e1) {
												Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, e1);
										}
											
											}
										else {
											loginFailedMessage.setVisible(true);
										}
									}
					} catch (SQLException e1) {
						Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, e1);
				}	
			}
		});
	
		btnLogin.setIcon(new ImageIcon(login.class.getResource("/images/btnLogin4.png")));
		btnLogin.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		btnLogin.setBounds(77, 359, 352, 40);
		leftPanel.add(btnLogin);
		
		txtPassword = new JPasswordField();
		txtPassword.setForeground(Color.BLACK);
		txtPassword.setBackground(Color.WHITE);
		txtPassword.setBorder(null);
		txtPassword.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		txtPassword.setBounds(77, 285, 310, 40);
		leftPanel.add(txtPassword);
		
		JCheckBox check = new JCheckBox("Show Password");
		check.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (check.isSelected()) {
					txtPassword.setEchoChar((char)0);
					eye.setVisible(true);
					invisible.setVisible(false);
				}
				else{
					txtPassword.setEchoChar('*');
					eye.setVisible(false);
					invisible.setVisible(true);
				}
			}
		});
		check.setHorizontalAlignment(SwingConstants.RIGHT);
		check.setBackground(null);
		check.setFont(new Font("Euclid Circular A Light", Font.PLAIN, 12));
		check.setBounds(301, 329, 128, 23);
		leftPanel.add(check);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(387, 285, 42, 40);
		leftPanel.add(panel);
		
		
		JPanel rightPanel = new JPanel();
		rightPanel.setBackground(Color.GRAY);
		rightPanel.setBounds(500, 0, 365, 560);
		logInFrame.getContentPane().add(rightPanel);
		
		JButton btnExit = new JButton("");
		btnExit.setBounds(252, 506, 94, 40);
		btnExit.setIcon(new ImageIcon(login.class.getResource("/images/closeBtn.png")));	
		btnExit.setBorderPainted(false); 
		btnExit.setContentAreaFilled(false); 
		btnExit.setFocusPainted(false); 
		btnExit.setOpaque(false);
		btnExit.setBorder(null);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close c = new close();
				c.exitFrame.setVisible(true);
						
			}
		});
		rightPanel.setLayout(null);
		btnExit.setForeground(Color.BLACK);
		btnExit.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		rightPanel.add(btnExit);
		
		
		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon(login.class.getResource("/images/logo.png")));
		logo.setBounds(121, 74, 137, 189);
		rightPanel.add(logo);
		
		JLabel title1 = new JLabel("Hospital");
		title1.setForeground(new Color(0x1C386A));
		title1.setHorizontalAlignment(SwingConstants.CENTER);
		title1.setFont(new Font("Poppins SemiBold", Font.PLAIN, 30));
		title1.setBounds(45, 264, 292, 46);
		rightPanel.add(title1);
		
		JLabel title2 = new JLabel("Management");
		title2.setHorizontalAlignment(SwingConstants.CENTER);
		title2.setFont(new Font("Poppins SemiBold", Font.PLAIN, 30));
		title2.setBounds(45, 307, 292, 46);
		rightPanel.add(title2);
		title2.setForeground(new Color(0x1C386A));
		
		JLabel title3 = new JLabel("System");
		title3.setHorizontalAlignment(SwingConstants.CENTER);
		title3.setFont(new Font("Poppins SemiBold", Font.PLAIN, 30));
		title3.setBounds(45, 348, 292, 46);
		rightPanel.add(title3);
		title3.setForeground(new Color(0x1C386A));
		
		
		JLabel bg = new JLabel("");
		bg.setIcon(new ImageIcon(login.class.getResource("/images/imageBackground.jpg")));
		bg.setBounds(-499, 0, 864, 560);
		rightPanel.add(bg);
		
		

	}
	/*=====================================================================CENTER WINDOW=======================================================*/
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
}
