
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;

import confirmDialog.close;
import confirmDialog.existed3;

import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;

public class signup1 {

	JFrame signUpFrame1;
	private JPasswordField passwordField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup1 window = new signup1();
					window.signUpFrame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public signup1() {
		initialize();
		centreWindow(signUpFrame1);
		Connect();
		
	}
//FROM SIGNUP2 METHOD
	String retypeCompanyID;
	public signup1(String companyID2) {
		initialize();
		Connect();
		centreWindow(signUpFrame1);
		retypeCompanyID = companyID2;
		System.out.print(retypeCompanyID);
		companyID.setText(retypeCompanyID);
		
	}
	
	
	/*=====================================================================DATABASE LOGIN=======================================================*/
	


	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField textField;
	private JPasswordField passwordField1;
	private JTextField companyID;
	
	public void Connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hospitalmanagementsystem", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(signup1.class.getName()).log(Level.SEVERE, null, e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Logger.getLogger(signup1.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		signUpFrame1 = new JFrame();
		signUpFrame1.setIconImage(Toolkit.getDefaultToolkit().getImage(signup1.class.getResource("/images/logo.png")));
		signUpFrame1.setBounds(100, 100, 450, 300);
		signUpFrame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		signUpFrame1.setUndecorated(true); // <-- the title bar is removed here
		signUpFrame1.setResizable(false);
		signUpFrame1.setSize(865, 560);
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combo box
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
		
		signUpFrame1.getContentPane().setLayout(null);
				
		JPanel leftPanel = new JPanel();
		leftPanel.setBorder(null);
		leftPanel.setBackground(new Color(0xECF5FA));
		leftPanel.setBounds(0, 0, 501, 560);
		signUpFrame1.getContentPane().add(leftPanel);
		leftPanel.setLayout(null);
		
		JLabel title = new JLabel("Register");
		title.setForeground(new Color(0x1E3C72));
		title.setBounds(75, 64, 138, 38);
		title.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 30));
		leftPanel.add(title);
		
		JLabel signUpFailedMessage = new JLabel("Password do not match. Please try again.");
		signUpFailedMessage.setHorizontalAlignment(SwingConstants.CENTER);
		signUpFailedMessage.setFont(new Font("Euclid Circular A", Font.PLAIN, 14));
		signUpFailedMessage.setForeground(Color.RED);
		signUpFailedMessage.setBounds(75, 491, 352, 19);
		signUpFailedMessage.setVisible(false);
		leftPanel.add(signUpFailedMessage);
		
		JLabel labelPassword = new JLabel("Retype Password :");
		labelPassword.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword.setBounds(75, 352, 191, 19);
		leftPanel.add(labelPassword);
		
		JButton btnSignUp = new JButton("");
		btnSignUp.setBackground(new Color(0,0,0,0));
		btnSignUp.setBorderPainted(false); 
		btnSignUp.setContentAreaFilled(false);
		btnSignUp.setOpaque(false);
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		
/*=====================================================================DATABASE SIGNUP=======================================================*/
			    	String id = companyID.getText();
					String username = textField.getText();
					String password = new String(passwordField1.getPassword());
					
					
					
					if(!(Arrays.equals(passwordField1.getPassword(), passwordField2.getPassword()))) {
						signUpFailedMessage.setVisible(true);
						
					} else {
						try {
							pst = con.prepareStatement("INSERT INTO login (id, username, password) values (?, ?, ?)");
							pst.setString(1, id);
							pst.setString(2, username);
							pst.setString(3, password);
							
							int k = pst.executeUpdate();
							if(k==1) {
								textField.setText(null);
								companyID.setText(null);
								passwordField1.setText(null);
								passwordField2.setText(null);
								signUpFrame1.setVisible(false);
								new login(username, password).logInFrame.setVisible(true);
							}

						} catch (SQLException e1){
							Logger.getLogger(signup1.class.getName()).log(Level.SEVERE, null, e1);
							existed3.main(null);							
						}
					}
			}
		});
	
		btnSignUp.setIcon(new ImageIcon(signup1.class.getResource("/images/btnSignUp.png")));
		btnSignUp.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		btnSignUp.setBounds(75, 442, 352, 38);
		leftPanel.add(btnSignUp);
		
		passwordField2 = new JPasswordField();
		passwordField2.addKeyListener(new KeyAdapter() {
			
		});
		passwordField2.setForeground(Color.BLACK);
		passwordField2.setBackground(Color.WHITE);
		passwordField2.setBorder(null);
		passwordField2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		passwordField2.setBounds(75, 382, 352, 40);
		leftPanel.add(passwordField2);
		
		textField = new JTextField();
		textField.setForeground(Color.BLACK);
		textField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		textField.setColumns(10);
		textField.setBorder(null);
		textField.setBackground(Color.WHITE);
		textField.setBounds(75, 222, 352, 38);
		leftPanel.add(textField);
		
		passwordField1 = new JPasswordField();
		passwordField1.setForeground(Color.BLACK);
		passwordField1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		passwordField1.setBorder(null);
		passwordField1.setBackground(Color.WHITE);
		passwordField1.setBounds(75, 301, 352, 40);
		leftPanel.add(passwordField1);
		
		JLabel labelPassword_1 = new JLabel("Password :");
		labelPassword_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_1.setBounds(75, 271, 122, 19);
		leftPanel.add(labelPassword_1);
		
		JLabel labelUsername_1 = new JLabel("Username :");
		labelUsername_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelUsername_1.setBounds(75, 192, 122, 19);
		leftPanel.add(labelUsername_1);
		
		JLabel labelUsername_1_1 = new JLabel("Retype Company ID:");
		labelUsername_1_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelUsername_1_1.setBounds(74, 113, 207, 19);
		leftPanel.add(labelUsername_1_1);
		
		companyID = new JTextField();
		companyID.setForeground(Color.BLACK);
		companyID.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		companyID.setColumns(10);
		companyID.setBorder(null);
		companyID.setBackground(Color.WHITE);
		companyID.setBounds(74, 143, 352, 38);
		leftPanel.add(companyID);
		
		JPanel rightPanel = new JPanel();
		rightPanel.setBackground(Color.GRAY);
		rightPanel.setBounds(500, 0, 365, 560);
		signUpFrame1.getContentPane().add(rightPanel);
		
		JButton btnLogin = new JButton("");
		btnLogin.setBounds(252, 506, 94, 40);
		btnLogin.setIcon(new ImageIcon(signup1.class.getResource("/images/btnSignIn.png")));	
		btnLogin.setBorderPainted(false); 
		btnLogin.setContentAreaFilled(false); 
		btnLogin.setFocusPainted(false); 
		btnLogin.setOpaque(false);
		btnLogin.setBorder(null);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.main(null);
				signUpFrame1.dispose();
				
			}
		});
		

		JButton btnExit = new JButton("X");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close c = new close();
				c.exitFrame.setVisible(true);
			}
		});
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnExit.setBorderPainted(false);
		btnExit.setBackground(new Color(205, 45, 43));
		btnExit.setBounds(276, 0, 89, 23);
		rightPanel.add(btnExit);
		
		rightPanel.setLayout(null);
		btnLogin.setForeground(Color.BLACK);
		btnLogin.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		rightPanel.add(btnLogin);
		
		JLabel bg = new JLabel("");
		bg.setIcon(new ImageIcon(signup1.class.getResource("/images/imageBackground.jpg")));
		bg.setBounds(-499, 0, 864, 560);
		rightPanel.add(bg);
		

	}
	/*=====================================================================CENTER WINDOW=======================================================*/
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
}
