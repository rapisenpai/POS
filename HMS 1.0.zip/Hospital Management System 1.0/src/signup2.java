
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;

import Dashboard.dashboard;
import confirmDialog.close;
import confirmDialog.error;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class signup2 {

	private JFrame signUpFrame2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup2 window = new signup2();
					window.signUpFrame2.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public signup2() {
		initialize();
		centreWindow(signUpFrame2);
		Connect();
		
	}
	
	
	/*=====================================================================DATABASE LOGIN=======================================================*/
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField companyIDtxtField;
	private JTextField residentialAdresstxtField;
	private JTextField firstNametxtField;
	private JTextField lastNametxtField;
	private JTextField emailAddresstxtField;
	private JTextField phoneNumtxtField;
	private JTextField designationtxtField;
	private JComboBox departmentcomboBox;
	
	public void Connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hospitalmanagementsystem", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(signup2.class.getName()).log(Level.SEVERE, null, e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Logger.getLogger(signup2.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		signUpFrame2 = new JFrame();
		signUpFrame2.setIconImage(Toolkit.getDefaultToolkit().getImage(signup2.class.getResource("/images/logo.jpg")));
		signUpFrame2.setBounds(100, 100, 450, 300);
		signUpFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		signUpFrame2.setUndecorated(true); // <-- the title bar is removed here
		signUpFrame2.setResizable(false);
		signUpFrame2.setSize(865, 560);
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combo box
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
		
		signUpFrame2.getContentPane().setLayout(null);
				
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(0xECF5FA));
		panel.setBounds(0, 0, 865, 560);
		signUpFrame2.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnLogin_1 = new JButton("");
		btnLogin_1.setOpaque(false);
		btnLogin_1.setForeground(Color.BLACK);
		btnLogin_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		btnLogin_1.setFocusPainted(false);
		btnLogin_1.setContentAreaFilled(false);
		btnLogin_1.setBorderPainted(false);
		btnLogin_1.setBorder(null);
		btnLogin_1.setBounds(397, 468, 94, 40);
		panel.add(btnLogin_1);
		
		JLabel title = new JLabel("Please enter the required information below.");
		title.setForeground(new Color(0x1E3C72));
		title.setBounds(51, 83, 444, 38);
		title.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		panel.add(title);
		
		JLabel labelPassword = new JLabel("Last Name:");
		labelPassword.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword.setBounds(51, 292, 191, 19);
		panel.add(labelPassword);
		
		companyIDtxtField = new JTextField();
		companyIDtxtField.setForeground(Color.BLACK);
		companyIDtxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		companyIDtxtField.setColumns(10);
		companyIDtxtField.setBorder(null);
		companyIDtxtField.setBackground(Color.WHITE);
		companyIDtxtField.setBounds(51, 162, 352, 38);
		panel.add(companyIDtxtField);
		
		JLabel labelPassword_1 = new JLabel("First Name:");
		labelPassword_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_1.setBounds(51, 211, 122, 19);
		panel.add(labelPassword_1);
		
		JLabel labelUsername_1 = new JLabel("Company ID:");
		labelUsername_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelUsername_1.setBounds(51, 132, 135, 19);
		panel.add(labelUsername_1);
		
		
		
		JLabel labelPassword_2 = new JLabel("Email Address:");
		labelPassword_2.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_2.setBounds(51, 373, 164, 19);
		panel.add(labelPassword_2);
		
		JLabel labelPassword_2_1 = new JLabel("Department:");
		labelPassword_2_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_2_1.setBounds(452, 373, 164, 19);
		panel.add(labelPassword_2_1);
		
		JLabel labelPassword_3 = new JLabel("Designation:");
		labelPassword_3.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_3.setBounds(452, 292, 191, 26);
		panel.add(labelPassword_3);
		
		JLabel labelPassword_1_1 = new JLabel("Phone Number:");
		labelPassword_1_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelPassword_1_1.setBounds(452, 211, 164, 19);
		panel.add(labelPassword_1_1);
		
		residentialAdresstxtField = new JTextField();
		residentialAdresstxtField.setForeground(Color.BLACK);
		residentialAdresstxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		residentialAdresstxtField.setColumns(10);
		residentialAdresstxtField.setBorder(null);
		residentialAdresstxtField.setBackground(Color.WHITE);
		residentialAdresstxtField.setBounds(452, 162, 352, 38);
		panel.add(residentialAdresstxtField);
		
		JLabel labelUsername_1_1 = new JLabel("Residential Address:");
		labelUsername_1_1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		labelUsername_1_1.setBounds(452, 132, 229, 19);
		panel.add(labelUsername_1_1);
		
		
		JButton btnExit = new JButton("X");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close c = new close();
				c.exitFrame.setVisible(true);
			}
		});
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnExit.setBorderPainted(false);
		btnExit.setBackground(new Color(205, 45, 43));
		btnExit.setBounds(776, 0, 89, 23);
		panel.add(btnExit);
		
		JButton btnLogin = new JButton("");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String checkID = companyIDtxtField.getText();
				try {
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM hospitalstaffs WHERE id='"+ checkID+"'");
					
					if (!rs.first()) {
						
						String companyId = companyIDtxtField.getText();
						String firstName = firstNametxtField.getText();
						String lastName = lastNametxtField.getText();
						String email = emailAddresstxtField.getText();
						String address = residentialAdresstxtField.getText();
						String phoneNum = phoneNumtxtField.getText();
						String role = designationtxtField.getText();
						String department = (String) departmentcomboBox.getSelectedItem();
						
						try {
//							INSERT DATA to EACH COLUMN in DATABASE
							pst = con.prepareStatement("INSERT INTO hospitalstaffs (id, firstname, lastname, emailaddress, residencialaddress, phonenumber, role, department)values(?, ?, ?, ?, ?, ?, ?, ?)");
							pst.setString(1, companyId);
							pst.setString(2, firstName);
							pst.setString(3, lastName);
							pst.setString(4, email);
							pst.setString(5, address);
							pst.setString(6, phoneNum);
							pst.setString(7, role);
							pst.setString(8, department);
							
							
							int k = pst.executeUpdate();
							
							if (k==1) {
								try {
									pst = con.prepareStatement("SELECT * FROM hospitalstaffs");
									rs = pst.executeQuery();
										while(rs.next()) {
											String id = rs.getString("id");
													if (companyId.equals(id)) {
														signUpFrame2.setVisible(false);
														new signup1(id).signUpFrame1.setVisible(true);	
														}
												}
								} catch (SQLException e1) {
									Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, e1);
							}
						
							} else {
								error.main(null);
							}
						} catch (SQLException e1) {
							Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e1);
							
						}
					}
					
				} catch(Exception e4){	
					error.main(null);
					
				}
				
				
				
				
				
			}
		});
		btnLogin.setIcon(new ImageIcon(signup2.class.getResource("/images/btnNext2.png")));
		btnLogin.setOpaque(false);
		btnLogin.setForeground(Color.BLACK);
		btnLogin.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		btnLogin.setFocusPainted(false);
		btnLogin.setContentAreaFilled(false);
		btnLogin.setBorderPainted(false);
		btnLogin.setBorder(null);
		btnLogin.setBounds(743, 495, 94, 40);
		panel.add(btnLogin);
		

		
		departmentcomboBox = new JComboBox();
		departmentcomboBox.setBackground(Color.WHITE);
		departmentcomboBox.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		departmentcomboBox.setModel(new DefaultComboBoxModel(new String[] {"-Select-", "Department of Anesthesiology", "Department of Dental Medicine", "Department of Emergency Medicine", "Department of Family and Community Medicine", "Department of Internal Medicine", "Department of Obstetrics and Gynecology", "Department of Ophthalmology", "Department of Orthopedics", "Department of Otorhinolaryngology-Head and Neck Surgery", "Department of Pediatrics", "Department of Surgery"}));
		departmentcomboBox.setBounds(452, 403, 352, 40);
		panel.add(departmentcomboBox);
				
		firstNametxtField = new JTextField();
		firstNametxtField.setForeground(Color.BLACK);
		firstNametxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		firstNametxtField.setColumns(10);
		firstNametxtField.setBorder(null);
		firstNametxtField.setBackground(Color.WHITE);
		firstNametxtField.setBounds(51, 243, 352, 38);
		panel.add(firstNametxtField);
		
		lastNametxtField = new JTextField();
		lastNametxtField.setForeground(Color.BLACK);
		lastNametxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		lastNametxtField.setColumns(10);
		lastNametxtField.setBorder(null);
		lastNametxtField.setBackground(Color.WHITE);
		lastNametxtField.setBounds(51, 322, 352, 38);
		panel.add(lastNametxtField);
		
		emailAddresstxtField = new JTextField();
		emailAddresstxtField.setForeground(Color.BLACK);
		emailAddresstxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		emailAddresstxtField.setColumns(10);
		emailAddresstxtField.setBorder(null);
		emailAddresstxtField.setBackground(Color.WHITE);
		emailAddresstxtField.setBounds(51, 405, 352, 38);
		panel.add(emailAddresstxtField);
		
		phoneNumtxtField = new JTextField();
		phoneNumtxtField.setForeground(Color.BLACK);
		phoneNumtxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		phoneNumtxtField.setColumns(10);
		phoneNumtxtField.setBorder(null);
		phoneNumtxtField.setBackground(Color.WHITE);
		phoneNumtxtField.setBounds(452, 241, 352, 38);
		panel.add(phoneNumtxtField);
		
		designationtxtField = new JTextField();
		designationtxtField.setForeground(Color.BLACK);
		designationtxtField.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		designationtxtField.setColumns(10);
		designationtxtField.setBorder(null);
		designationtxtField.setBackground(Color.WHITE);
		designationtxtField.setBounds(452, 324, 352, 38);
		panel.add(designationtxtField);
		

		JLabel bg = new JLabel("");
		bg.setIcon(new ImageIcon(signup2.class.getResource("/images/imageBackground.jpg")));
		bg.setBounds(0, 0, 865, 560);
		panel.add(bg);

		
		

	}
	/*=====================================================================CENTER WINDOW=======================================================*/
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
}
