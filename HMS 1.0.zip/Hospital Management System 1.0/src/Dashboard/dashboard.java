package Dashboard;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.plaf.ColorUIResource;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import confirmDialog.deleted;
import confirmDialog.error;
import confirmDialog.existed;
import confirmDialog.exit;
import confirmDialog.success;
import confirmDialog.update;

import java.awt.ScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollBar;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.net.URL;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.DropMode;

public class dashboard {

	public JFrame mainFrame;
	private JTextField txtNameHere;
	private JTextField firstName;
	private JTextField lastName;
	private JTextField height;
	private JTextField weight;
	private JTextField email;
	private JTextField reason;
	private JTextField textFieldAllergies;
	private JTextField textFieldOtherIllnesses;
	private JTextField textFieldOperations;
	private JTextField textFieldMedications;
	private JTextField patientId;
	private JTextField age;
	private JTable table;
	private int flag = 0;
	private JLabel doesNotExist;
	private JButton btnUpdate;
	private JLabel isNotExsist1;
	private JButton btnSave1;
	private JCheckBox chckbxYes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					dashboard window = new dashboard();
					window.mainFrame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
					error.main(null);
				}
				
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public dashboard() {
		initialize();
		centreWindow(mainFrame);
		Connect();
		FetchPMH();
		FetchGPI();
		displayThisToDiagnosisInfo();
		countForGPI();
		countForHSI();
		FetchHSR();
		
	}
	
	
//	METHOD FOR NAME IN DASHBOARD
	String profileId;
	String userName;
	String department;
	public dashboard(String user, String id) {
		initialize();
		Connect();
		FetchPMH();
		FetchGPI();
		displayThisToDiagnosisInfo();
		countForGPI();
		countForHSI();
		FetchHSR();
		userName = user;
		profileId = id;
		// TODO Auto-generated constructor stub
		txtNameHere.setText(userName.toUpperCase());
//		Test
		System.out.println("User Name: " + userName);
		System.out.println("user ID: " + profileId);
		
		try {
			pst = con.prepareStatement("SELECT * FROM hospitalstaffs WHERE id=?");
			pst.setString(1, profileId);
			rs = pst.executeQuery();
			if (rs.next() == true) {
				firstNameProfile.setText(rs.getString(2));
				lastNameProfile.setText(rs.getString(3));
				designationProfile.setText(rs.getString(7));
				phoneProfile.setText(rs.getString(6));
				emailProfile.setText(rs.getString(4));
				addressProfile.setText(rs.getString(5));
				department = rs.getString(7);
				
			} else {
				firstNameProfile.setText("");
				lastNameProfile.setText("");
				designationProfile.setText("");
				phoneProfile.setText("");
				emailProfile.setText("");
				addressProfile.setText("");
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			error.main(null);
		}
		
		
	}



	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField textFieldDate;
	private JTextField textFieldSearch1;
	private JTable GeneralPatientInformationTable;
	private JTextField textFieldSearch2;
	private JTable PatientMedicalHistoryTable;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textFieldSearch;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField searchID1;
	private JTable DiagnosisInfoTable;
	private JTextField textFieldSymptoms;
	private JTextField textFieldDiagnosis;
	private JTextField textFieldMedicines;
	private JTextField lblSelectedPatient1;
	private JTextField lblSelectedPatient2;
	private JTextField lblSelectedPatient3;
	private JTextField textField_13;
	private JTextField textField_16;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField totalPatients;
	private JTextField totalHospitalStaff;
	private int numberRow = 0;
	private JTable doctorsTableList;
	JScrollPane scrollPane2;
	private JTextField lastNameProfile;
	private JTextField designationProfile;
	private JTextField phoneProfile;
	private JTextField emailProfile;
	private JTextField addressProfile;
	private JTextField firstNameProfile;
	
	public void Connect(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hospitalmanagementsystem", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e);
		}  catch (SQLException ex) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, ex);
			error.main(null);
		}
		
		
	}

//	=====================================================================================================================================
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
//	======================================================================================================================================

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings("unchecked")
	private void initialize() {
		
		for ( LookAndFeelInfo info : UIManager.getInstalledLookAndFeels() ) {
			if ( "Metal".equals(info.getName()) ) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					error.main(null);
					e.printStackTrace();
				}
				break;
			}
		}
		
		mainFrame = new JFrame();
		mainFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(dashboard.class.getResource("/images/logo.jpg")));
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setSize(1380, 740);
		mainFrame.setResizable(false);
		mainFrame.setTitle("Hospital Management System");
//		mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		mainFrame.getContentPane().setLayout(null);
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color (0x1E3C72));
		panel.setForeground(Color.BLACK);
		panel.setBounds(0, 0, 327, 701);
		mainFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combo box
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        
        
        
//=========================================================================================================================================
        JLabel selector1 = new JLabel("");
		selector1.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector1.setBounds(0, 250, 10, 51);
		panel.add(selector1);
		
		JLabel selector2 = new JLabel("");
		selector2.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector2.setBounds(0, 306, 5, 51);
		panel.add(selector2);
		
		JLabel selector3 = new JLabel("");
		selector3.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector3.setBounds(0, 363, 5, 51);
		panel.add(selector3);
		
		JLabel selector4 = new JLabel("");
		selector4.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector4.setBounds(0, 420, 5, 51);
		panel.add(selector4);
		
		JLabel selector5 = new JLabel("");
		selector5.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector5.setBounds(0, 477, 5, 51);
		panel.add(selector5);
		
		JLabel selector6 = new JLabel("");
		selector6.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector6.setBounds(0, 534, 5, 51);
		panel.add(selector6);
		
		JLabel selector7 = new JLabel("");
		selector7.setIcon(new ImageIcon(dashboard.class.getResource("/images/selector.png")));
		selector7.setBounds(0, 591, 5, 51);
		panel.add(selector7);
        
      //==================================================================TABS ============================================================		
       
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(319, -27, 1055, 728);
		mainFrame.getContentPane().add(tabbedPane);
		
		JPanel tab1 = new JPanel();
		tab1.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab1, null);
		tab1.setLayout(null);
		

		totalPatients = new JTextField();
		totalPatients.setEditable(false);
		totalPatients.setFont(new Font("Poppins SemiBold", Font.BOLD, 60));
		totalPatients.setHorizontalAlignment(SwingConstants.CENTER);
		totalPatients.setText("00");
		totalPatients.setBorder(null);
		totalPatients.setBackground(Color.WHITE);
		
		totalPatients.setBounds(60, 425, 196, 66);
		tab1.add(totalPatients);
		totalPatients.setColumns(10);
		
		totalHospitalStaff = new JTextField();
		totalHospitalStaff.setEditable(false);
		totalHospitalStaff.setText("00");
		totalHospitalStaff.setHorizontalAlignment(SwingConstants.CENTER);
		totalHospitalStaff.setFont(new Font("Poppins SemiBold", Font.BOLD, 60));
		totalHospitalStaff.setColumns(10);
		totalHospitalStaff.setBorder(null);
		totalHospitalStaff.setBackground(Color.WHITE);
		totalHospitalStaff.setBounds(293, 425, 196, 66);
		tab1.add(totalHospitalStaff);

		JLabel lblNewLabel_2 = new JLabel("Total Patients");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setBounds(79, 386, 158, 28);
		tab1.add(lblNewLabel_2);
		
		
		JLabel lblNewLabel_3 = new JLabel("Available Staff");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(314, 386, 158, 28);
		tab1.add(lblNewLabel_3);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(dashboard.class.getResource("/images/bg2.jpg")));
		lblNewLabel.setBounds(0, 0, 1050, 700);
		tab1.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("New label");
		label_1.setBounds(102, 363, 46, 14);
		tab1.add(label_1);
	
		
		
		
		JPanel tab2 = new JPanel();
		tab2.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab2, null);
		tab2.setLayout(null);
		
		JLabel lbl23_2 = new JLabel("Patient ID:");
		lbl23_2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl23_2.setBounds(306, 42, 100, 22);
		tab2.add(lbl23_2);
		
		searchID1 = new JTextField();
		searchID1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				DefaultTableModel table = (DefaultTableModel) DiagnosisInfoTable.getModel();
				String search = searchID1.getText().toLowerCase();
				TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
				DiagnosisInfoTable.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
			}
		});
		searchID1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		searchID1.setColumns(10);
		searchID1.setBounds(400, 39, 209, 29);
		tab2.add(searchID1);
		JButton btnSearch4 = new JButton(" Search ID");
		
		btnSearch4.setIcon(new ImageIcon(dashboard.class.getResource("/images/magnifying-glass-search.png")));
		btnSearch4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnSearch4.setBounds(619, 38, 158, 29);
		tab2.add(btnSearch4);
		
		JScrollPane scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(39, 91, 967, 354);
		tab2.add(scrollPane1);
		
		DiagnosisInfoTable = new JTable();
		DiagnosisInfoTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = DiagnosisInfoTable.getSelectedRow();
				TableModel model = (TableModel) DiagnosisInfoTable.getModel();
				searchID1.setText(model.getValueAt(i, 0).toString());
				
				String srhID =  searchID1.getText();
				try {
					
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+srhID+"'");
					if (!rs.first()) {
						isNotExsist1.setVisible(true);
						textFieldSymptoms.setEnabled(false);
						textFieldDiagnosis.setEnabled(false);
						textFieldMedicines.setEnabled(false);
						btnSave1.setEnabled(false);
						chckbxYes.setEnabled(false);
					} else {
						isNotExsist1.setVisible(false);
						flag = 1;
						textFieldSymptoms.setEnabled(true);
						textFieldDiagnosis.setEnabled(true);
						textFieldMedicines.setEnabled(true);
						btnSave1.setEnabled(true);
						chckbxYes.setEnabled(true);
					}	
				} catch(Exception e4){
					error.main(null);
					
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM generalpatientinformation WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						lblSelectedPatient1.setText(rs.getString(1));
						lblSelectedPatient2.setText(rs.getString(2));
						lblSelectedPatient3.setText(rs.getString(3));
						
			
					} else {
						lblSelectedPatient1.setText("");
						lblSelectedPatient2.setText("");
						lblSelectedPatient3.setText("");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
			}
		});
		DiagnosisInfoTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Patient ID", "First Name", "Last Name", "Birth Date", "Gender", "Age", "Height", "Weight"
			}
		));
		DiagnosisInfoTable.getColumnModel().getColumn(0).setPreferredWidth(65);
		DiagnosisInfoTable.getColumnModel().getColumn(0).setMinWidth(65);
		DiagnosisInfoTable.getColumnModel().getColumn(1).setPreferredWidth(150);
		DiagnosisInfoTable.getColumnModel().getColumn(1).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(2).setPreferredWidth(150);
		DiagnosisInfoTable.getColumnModel().getColumn(2).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(3).setPreferredWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(3).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(4).setPreferredWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(4).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(5).setPreferredWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(5).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(6).setPreferredWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(6).setMinWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(7).setPreferredWidth(100);
		DiagnosisInfoTable.getColumnModel().getColumn(7).setMinWidth(100);
		DiagnosisInfoTable.setShowVerticalLines(false);
		DiagnosisInfoTable.setFont(new Font("Euclid Circular A Light", Font.PLAIN, 13));
		DiagnosisInfoTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		scrollPane1.setColumnHeaderView(DiagnosisInfoTable);
		scrollPane1.setViewportView(DiagnosisInfoTable);
		
		textFieldSymptoms = new JTextField();
		textFieldSymptoms.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldSymptoms.setColumns(10);
		textFieldSymptoms.setBounds(39, 573, 428, 29);
		tab2.add(textFieldSymptoms);
		
		JLabel lblSymptoms = new JLabel("Symptoms:");
		lblSymptoms.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblSymptoms.setBounds(39, 547, 181, 22);
		tab2.add(lblSymptoms);
		
		JLabel lblDiagnosis = new JLabel("Diagnosis:");
		lblDiagnosis.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblDiagnosis.setBounds(39, 613, 295, 22);
		tab2.add(lblDiagnosis);
		
		textFieldDiagnosis = new JTextField();
		textFieldDiagnosis.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldDiagnosis.setColumns(10);
		textFieldDiagnosis.setBounds(39, 637, 428, 29);
		tab2.add(textFieldDiagnosis);
		
		JLabel updtLbl13_1_1 = new JLabel("Medicines:");
		updtLbl13_1_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl13_1_1.setBounds(528, 489, 295, 22);
		tab2.add(updtLbl13_1_1);
		
		textFieldMedicines = new JTextField();
		textFieldMedicines.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldMedicines.setColumns(10);
		textFieldMedicines.setBounds(528, 513, 428, 29);
		tab2.add(textFieldMedicines);
		
		JLabel lblWardRequired = new JLabel("Ward Required?");
		lblWardRequired.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblWardRequired.setBounds(528, 562, 144, 22);
		tab2.add(lblWardRequired);
		
		chckbxYes = new JCheckBox("Yes");
		chckbxYes.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxYes.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		chckbxYes.setBounds(680, 564, 97, 23);
		tab2.add(chckbxYes);
		
		
		
		JLabel lblTypeOfWard = new JLabel("Type of Ward:");
		lblTypeOfWard.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblTypeOfWard.setBounds(528, 613, 144, 22);
		tab2.add(lblTypeOfWard);
		
		JComboBox comboBoxTypeOfWard = new JComboBox();
		comboBoxTypeOfWard.setEnabled(false);
		comboBoxTypeOfWard.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		comboBoxTypeOfWard.setModel(new DefaultComboBoxModel(new String[] {"General", "Single", "Dou"}));
		comboBoxTypeOfWard.setBounds(679, 615, 98, 22);
		tab2.add(comboBoxTypeOfWard);
		
		isNotExsist1 = new JLabel("Patient ID does not exist.");
		isNotExsist1.setForeground(Color.RED);
		isNotExsist1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		isNotExsist1.setBounds(434, 67, 144, 22);
		tab2.add(isNotExsist1);
		
		isNotExsist1.setVisible(false);
		
		chckbxYes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxYes.isSelected()) {
					comboBoxTypeOfWard.setEnabled(true);
					
				} else {
					comboBoxTypeOfWard.setEnabled(false);
					
				}
			}
		});
		btnSave1 = new JButton(" Save");
		btnSearch4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String srhID =  searchID1.getText();
				try {
					
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+srhID+"'");
					if (!rs.first()) {
						isNotExsist1.setVisible(true);
						textFieldSymptoms.setEnabled(false);
						textFieldDiagnosis.setEnabled(false);
						textFieldMedicines.setEnabled(false);
						btnSave1.setEnabled(false);
						chckbxYes.setEnabled(false);
					} else {
						isNotExsist1.setVisible(false);
						flag = 1;
						textFieldSymptoms.setEnabled(true);
						textFieldDiagnosis.setEnabled(true);
						textFieldMedicines.setEnabled(true);
						btnSave1.setEnabled(true);
						chckbxYes.setEnabled(true);
					}	
				} catch(Exception e4){
					error.main(null);
					
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM generalpatientinformation WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						lblSelectedPatient1.setText(rs.getString(1));
						lblSelectedPatient2.setText(rs.getString(2));
						lblSelectedPatient3.setText(rs.getString(3));
						
			
					} else {
						lblSelectedPatient1.setText("");
						lblSelectedPatient2.setText("");
						lblSelectedPatient3.setText("");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
			
			}
		});
		
		
		btnSave1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = lblSelectedPatient1.getText();
				String firstName = lblSelectedPatient2.getText();
				String lastName = lblSelectedPatient3.getText();
				String symptoms = textFieldSymptoms.getText();
				String diagnosis = textFieldDiagnosis.getText();
				String medicines = textFieldMedicines.getText();
				String ward = (String) comboBoxTypeOfWard.getSelectedItem();
				
				try {
					pst = con.prepareStatement("INSERT INTO diagnosisinformation(id, firstname, lastname, symptoms, diagnosis, medicines, ward)values(?, ?, ?, ?, ?, ?, ?)");
					pst.setString(1, id);
					pst.setString(2, firstName);
					pst.setString(3, lastName);
					pst.setString(4, symptoms);
					pst.setString(5, diagnosis);
					pst.setString(6, medicines);
					pst.setString(7, ward);
					
					int k = pst.executeUpdate();
					
					if (k==1) {
						success.main(null);
						lblSelectedPatient1.setText(null);
						lblSelectedPatient2.setText(null);
						lblSelectedPatient3.setText(null);
						textFieldSymptoms.setText(null);
						textFieldDiagnosis.setText(null);
						textFieldMedicines.setText(null);
						comboBoxTypeOfWard.setSelectedItem(0);
					}
				
					
				} catch (Exception e5){
					error.main(null);
					Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e5);
					
				}
				
				
			}
		});
		btnSave1.setIcon(new ImageIcon(dashboard.class.getResource("/images/floppy-disk.png")));
		btnSave1.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnSave1.setBounds(848, 637, 158, 29);
		tab2.add(btnSave1);
		
		JLabel selectedPatient = new JLabel("Selected Patient: (Search from the table)");
		selectedPatient.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		selectedPatient.setBounds(39, 465, 344, 22);
		tab2.add(selectedPatient);
		
		lblSelectedPatient1 = new JTextField();
		lblSelectedPatient1.setEditable(false);
		lblSelectedPatient1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		lblSelectedPatient1.setColumns(10);
		lblSelectedPatient1.setBounds(39, 489, 97, 29);
		tab2.add(lblSelectedPatient1);
		
		lblSelectedPatient2 = new JTextField();
		lblSelectedPatient2.setEditable(false);
		lblSelectedPatient2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		lblSelectedPatient2.setColumns(10);
		lblSelectedPatient2.setBounds(135, 489, 171, 29);
		tab2.add(lblSelectedPatient2);
		
		lblSelectedPatient3 = new JTextField();
		lblSelectedPatient3.setEditable(false);
		lblSelectedPatient3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		lblSelectedPatient3.setColumns(10);
		lblSelectedPatient3.setBounds(306, 489, 161, 29);
		tab2.add(lblSelectedPatient3);
		
		JLabel lblIName = new JLabel("ID                            FIRST NAME                                  LAST NAME");
		lblIName.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		lblIName.setBounds(39, 518, 428, 22);
		tab2.add(lblIName);
		
		
		JPanel tab3 = new JPanel();
		tabbedPane.addTab("New tab", null, tab3, null);
		tab3.setLayout(null);
		
		
	
		
		firstNameProfile = new JTextField ("First Name");
		firstNameProfile.setEditable(false);
		firstNameProfile.setBackground(new Color (0x161B25));
		firstNameProfile.setForeground(Color.WHITE);
		firstNameProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 45));
		firstNameProfile.setBounds(499, 210, 393, 46);
		firstNameProfile.setBorder(null);
		tab3.add(firstNameProfile);
		
				
		lastNameProfile = new JTextField("Last Name");
		lastNameProfile.setEditable(false);
		lastNameProfile.setForeground(Color.WHITE);
		lastNameProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 45));
		lastNameProfile.setBackground(new Color(22, 27, 37));
		lastNameProfile.setBounds(499, 259, 393, 46);
		lastNameProfile.setBorder(null);
		tab3.add(lastNameProfile);
		
		designationProfile = new JTextField("Designation");
		designationProfile.setForeground(Color.white);
		designationProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 25));
		designationProfile.setEditable(false);
		designationProfile.setBorder(null);
		designationProfile.setBackground(new Color(0x2E323B));
		designationProfile.setBounds(499, 316, 393, 39);
		
		tab3.add(designationProfile);
		
		
		
		JLabel phoneProfileLabel = new JLabel("Phone:");
		phoneProfileLabel.setForeground(Color.WHITE);
		phoneProfileLabel.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		phoneProfileLabel.setBackground(Color.WHITE);
		phoneProfileLabel.setBounds(499, 366, 80, 14);
		tab3.add(phoneProfileLabel);
		
		phoneProfile = new JTextField("63-9XXXXXXXXX");
		phoneProfile.setForeground(Color.WHITE);
		phoneProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		phoneProfile.setEditable(false);
		phoneProfile.setBorder(null);
		phoneProfile.setBackground(new Color(0x161B25));
		phoneProfile.setBounds(499, 382, 197, 23);
		tab3.add(phoneProfile);
		
		JLabel emailProfileLabel = new JLabel("Email:");
		emailProfileLabel.setForeground(Color.WHITE);
		emailProfileLabel.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		emailProfileLabel.setBackground(Color.WHITE);
		emailProfileLabel.setBounds(499, 416, 80, 14);
		tab3.add(emailProfileLabel);
		
		emailProfile = new JTextField("lastname.firstname@hosp.ph");
		emailProfile.setHorizontalAlignment(SwingConstants.LEFT);
		emailProfile.setForeground(Color.WHITE);
		emailProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		emailProfile.setEditable(false);
		emailProfile.setBorder(null);
		emailProfile.setBackground(new Color(0x161B25));
		emailProfile.setBounds(499, 432, 393, 23);
		tab3.add(emailProfile);
		
		
		JLabel addressProfileLabel = new JLabel("Adress:");
		addressProfileLabel.setForeground(Color.WHITE);
		addressProfileLabel.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		addressProfileLabel.setBackground(Color.WHITE);
		addressProfileLabel.setBounds(499, 466, 80, 14);
		tab3.add(addressProfileLabel);
		
		addressProfile = new JTextField("Barangay, Municipality, Province, ZIP Code");
		addressProfile.setForeground(Color.WHITE);
		addressProfile.setFont(new Font("Poppins SemiBold", Font.PLAIN, 15));
		addressProfile.setEditable(false);
		addressProfile.setBorder(null);
		addressProfile.setBackground(new Color(0x161B25));
		addressProfile.setBounds(499, 482, 393, 23);
		tab3.add(addressProfile);
		
		JButton btnSave2_1_1 = new JButton(" Edit");
		btnSave2_1_1.setIcon(new ImageIcon(dashboard.class.getResource("/images/editing.png")));
		btnSave2_1_1.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnSave2_1_1.setBounds(685, 639, 158, 29);
		tab3.add(btnSave2_1_1);
		
		JButton btnSave2_1 = new JButton("Update");
		
		btnSave2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstNameProfile.setEditable(true);
				lastNameProfile.setEditable(true);
				designationProfile.setEditable(true);
				phoneProfile.setEditable(true);
				emailProfile.setEditable(true);
				addressProfile.setEditable(true);
				btnSave2_1.setEnabled(true);
				
				Font font1 = firstNameProfile.getFont();
				Map attributes1 = font1.getAttributes();
				attributes1.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				firstNameProfile.setFont(font1.deriveFont(attributes1));
				
				Font font2 = lastNameProfile.getFont();
				Map attributes2 = font2.getAttributes();
				attributes2.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				lastNameProfile.setFont(font2.deriveFont(attributes2));
				
				Font font3 = designationProfile.getFont();
				Map attributes3 = font3.getAttributes();
				attributes3.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				designationProfile.setFont(font3.deriveFont(attributes3));
				
				Font font4 = phoneProfile.getFont();
				Map attributes4 = font4.getAttributes();
				attributes4.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				phoneProfile.setFont(font4.deriveFont(attributes4));
				
				Font font5 = emailProfile.getFont();
				Map attributes5 = font5.getAttributes();
				attributes5.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				emailProfile.setFont(font5.deriveFont(attributes5));
				
				Font font6 = addressProfile.getFont();
				Map attributes6 = font6.getAttributes();
				attributes6.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				addressProfile.setFont(font6.deriveFont(attributes6));
			}
		});
		
		
		btnSave2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstNameProfile.setEditable(false);
				lastNameProfile.setEditable(false);
				designationProfile.setEditable(false);
				phoneProfile.setEditable(false);
				emailProfile.setEditable(false);
				addressProfile.setEditable(false);
				btnSave2_1.setEnabled(false);
				
				
				Font font1 = firstNameProfile.getFont();
				Map attributes1 = font1.getAttributes();
				attributes1.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				firstNameProfile.setFont(font1.deriveFont(attributes1));
				
				Font font2 = lastNameProfile.getFont();
				Map attributes2 = font2.getAttributes();
				attributes2.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				lastNameProfile.setFont(font2.deriveFont(attributes2));
				
				Font font3 = designationProfile.getFont();
				Map attributes3 = font3.getAttributes();
				attributes3.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				designationProfile.setFont(font3.deriveFont(attributes3));
				
				Font font4 = phoneProfile.getFont();
				Map attributes4 = font4.getAttributes();
				attributes4.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				phoneProfile.setFont(font4.deriveFont(attributes4));
				
				Font font5 = emailProfile.getFont();
				Map attributes5 = font5.getAttributes();
				attributes5.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				emailProfile.setFont(font5.deriveFont(attributes5));
				
				Font font6 = addressProfile.getFont();
				Map attributes6 = font6.getAttributes();
				attributes6.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
				addressProfile.setFont(font6.deriveFont(attributes6));
				

				String firstname =  firstNameProfile.getText();
				String lastname = lastNameProfile.getText();
				String emailaddress = emailProfile.getText(); 
				String residencialaddress = addressProfile.getText(); 
				String phonenumber = phoneProfile.getText();
				String role = designationProfile.getText();
			
				
				try {
					pst = con.prepareStatement("UPDATE hospitalstaffs SET firstname=?, lastname=?, emailaddress=?, residencialaddress=?, phonenumber=?, role=?, department=? WHERE id=?");
					pst.setString(1, firstname);
					pst.setString(2, lastname);
					pst.setString(3, emailaddress);
					pst.setString(4, residencialaddress);
					pst.setString(5, phonenumber);
					pst.setString(6, role);
					pst.setString(7, department);
					pst.setString(8, profileId);
		
					int k = pst.executeUpdate();
					
					if (k==1) {
						
						try {
							pst = con.prepareStatement("SELECT * FROM hospitalstaffs WHERE id=?");
							pst.setString(1, profileId);
							rs = pst.executeQuery();
							if (rs.next() == true) {
								txtNameHere.setText("HELLO, " + rs.getString(2).toUpperCase() + " " + rs.getString(3).toUpperCase());
								
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}	
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
			}
		});
		btnSave2_1.setEnabled(false);
		
		btnSave2_1.setIcon(new ImageIcon(dashboard.class.getResource("/images/refresh.png")));
		btnSave2_1.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnSave2_1.setBounds(853, 639, 158, 29);
		tab3.add(btnSave2_1);
		
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(dashboard.class.getResource("/images/bgFinal.png")));
		lblNewLabel_1.setBounds(162, 147, 749, 420);
		tab3.add(lblNewLabel_1);
		
		JLabel lblDashboard = new JLabel("");
		lblDashboard.setIcon(new ImageIcon(dashboard.class.getResource("/images/5330591.jpg")));
		lblDashboard.setBounds(0, 0, 1050, 700);
		tab3.add(lblDashboard);
		
		
		
		JPanel tab4 = new JPanel();
		tab4.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab4, null);
		tab4.setLayout(null);
		
		JLabel lbl1 = new JLabel("General Patient Information");
		lbl1.setBackground(Color.WHITE);
		lbl1.setHorizontalAlignment(SwingConstants.LEFT);
		lbl1.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		lbl1.setBounds(33, 36, 279, 36);
		tab4.add(lbl1);
		
		JLabel lbl3 = new JLabel("Patient Name:");
		lbl3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl3.setBounds(33, 136, 122, 22);
		tab4.add(lbl3);
		
		firstName = new JTextField();
		firstName.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		firstName.setBounds(33, 161, 209, 29);
		tab4.add(firstName);
		firstName.setColumns(10);
		
		lastName = new JTextField();
		lastName.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		lastName.setColumns(10);
		lastName.setBounds(252, 161, 209, 29);
		tab4.add(lastName);
		
		JLabel lbl4 = new JLabel("First Name");
		lbl4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		lbl4.setBounds(33, 193, 122, 14);
		tab4.add(lbl4);
		
		JLabel lbl5 = new JLabel("Last Name");
		lbl5.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		lbl5.setBounds(252, 195, 122, 14);
		tab4.add(lbl5);
		
		JLabel lbl6 = new JLabel("Patient Birthdate:");
		lbl6.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl6.setBounds(33, 218, 170, 22);
		tab4.add(lbl6);
		
		JLabel lbl10 = new JLabel("Patient Gender:");
		lbl10.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl10.setBounds(33, 301, 135, 22);
		tab4.add(lbl10);
		
		JComboBox gender = new JComboBox();
		gender.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		gender.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female", "Other"}));
		gender.setBounds(33, 326, 135, 29);
		tab4.add(gender);
		
		JLabel lbl12 = new JLabel("Patient Height (cm's):");
		lbl12.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl12.setBounds(33, 369, 181, 22);
		tab4.add(lbl12);
		
		JLabel lbl13 = new JLabel("Patient Weight (kg's):");
		lbl13.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl13.setBounds(252, 369, 181, 22);
		tab4.add(lbl13);
		
		height = new JTextField();
		height.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		height.setColumns(10);
		height.setBounds(33, 400, 209, 29);
		tab4.add(height);
		
		weight = new JTextField();
		weight.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		weight.setColumns(10);
		weight.setBounds(252, 400, 209, 29);
		tab4.add(weight);
		
		JLabel lbl14 = new JLabel("Patient E-Mail:");
		lbl14.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl14.setBounds(33, 440, 181, 22);
		tab4.add(lbl14);
		
		email = new JTextField();
		email.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		email.setColumns(10);
		email.setBounds(33, 466, 428, 29);
		tab4.add(email);
		
		JLabel lbl16 = new JLabel("Reason for seeing the doctor:");
		lbl16.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl16.setBounds(33, 506, 295, 22);
		tab4.add(lbl16);
		
		reason = new JTextField();
		reason.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		reason.setColumns(10);
		reason.setBounds(33, 530, 428, 29);
		tab4.add(reason);
		
		JLabel lbl17 = new JLabel("Patient Medical History");
		lbl17.setHorizontalAlignment(SwingConstants.LEFT);
		lbl17.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		lbl17.setBackground(Color.WHITE);
		lbl17.setBounds(501, 24, 279, 36);
		tab4.add(lbl17);
		
		JLabel lblNewLabel_2_4 = new JLabel("Please list any drug allergies:");
		lblNewLabel_2_4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblNewLabel_2_4.setBounds(501, 71, 259, 22);
		tab4.add(lblNewLabel_2_4);
		
		textFieldAllergies = new JTextField();
		textFieldAllergies.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldAllergies.setColumns(10);
		textFieldAllergies.setBounds(501, 96, 428, 29);
		tab4.add(textFieldAllergies);
		
		JLabel lbl18 = new JLabel("Have you ever had (Please check all that apply)");
		lbl18.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl18.setBounds(501, 136, 428, 22);
		tab4.add(lbl18);
		
		JCheckBox checkBox1 = new JCheckBox("Anemia");
		checkBox1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox1.setBounds(501, 165, 163, 23);
		tab4.add(checkBox1);
		
		JCheckBox checkBox10 = new JCheckBox("Gallstones");
		checkBox10.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox10.setBounds(677, 165, 163, 23);
		tab4.add(checkBox10);
		
		JCheckBox checkBox19 = new JCheckBox("Kidney Disease");
		checkBox19.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox19.setBounds(850, 165, 163, 23);
		tab4.add(checkBox19);
		
		JCheckBox checkBox2 = new JCheckBox("Asthma");
		checkBox2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox2.setBounds(501, 191, 163, 23);
		tab4.add(checkBox2);
		
		JCheckBox checkBox11 = new JCheckBox("Heart Disease");
		checkBox11.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox11.setBounds(677, 191, 163, 23);
		tab4.add(checkBox11);
		
		JCheckBox checkBox20 = new JCheckBox("Liver Disease");
		checkBox20.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox20.setBounds(850, 191, 163, 23);
		tab4.add(checkBox20);
		
		JCheckBox checkBox3 = new JCheckBox("Arthritis");
		checkBox3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox3.setBounds(501, 217, 163, 23);
		tab4.add(checkBox3);
		
		JCheckBox checkBox12 = new JCheckBox("Heart Attack");
		checkBox12.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox12.setBounds(677, 217, 163, 23);
		tab4.add(checkBox12);
		
		JCheckBox checkBox21 = new JCheckBox("Sleep Apnea");
		checkBox21.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox21.setBounds(850, 217, 163, 23);
		tab4.add(checkBox21);
		
		JCheckBox checkBox4 = new JCheckBox("Cancer");
		checkBox4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox4.setBounds(501, 243, 163, 23);
		tab4.add(checkBox4);
		
		JCheckBox checkBox13 = new JCheckBox("Rheumatic Fever");
		checkBox13.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox13.setBounds(677, 243, 163, 23);
		tab4.add(checkBox13);
		
		JCheckBox checkBox22 = new JCheckBox("Use a C-PAP machine");
		checkBox22.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox22.setBounds(850, 243, 163, 23);
		tab4.add(checkBox22);
		
		JCheckBox checkBox5 = new JCheckBox("Gout");
		checkBox5.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox5.setBounds(501, 269, 163, 23);
		tab4.add(checkBox5);
		
		JCheckBox checkBox14 = new JCheckBox("High Blood Pressure");
		checkBox14.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox14.setBounds(677, 269, 163, 23);
		tab4.add(checkBox14);
		
		JCheckBox checkBox23 = new JCheckBox("Thyroid Problems");
		checkBox23.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox23.setBounds(850, 269, 163, 23);
		tab4.add(checkBox23);
		
		JCheckBox checkBox6 = new JCheckBox("Diabetes");
		checkBox6.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox6.setBounds(501, 295, 163, 23);
		tab4.add(checkBox6);
		
		JCheckBox checkBox15 = new JCheckBox("Digestive Problems");
		checkBox15.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox15.setBounds(677, 295, 163, 23);
		tab4.add(checkBox15);
		
		JCheckBox checkBox24 = new JCheckBox("Tuberculosis");
		checkBox24.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox24.setBounds(850, 295, 163, 23);
		tab4.add(checkBox24);
		
		JCheckBox checkBox9 = new JCheckBox("Fainting Spells");
		checkBox9.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox9.setBounds(501, 373, 163, 23);
		tab4.add(checkBox9);
		
		JCheckBox checkBox18 = new JCheckBox("Hepatitis");
		checkBox18.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox18.setBounds(677, 373, 163, 23);
		tab4.add(checkBox18);
		
		JCheckBox checkBox27 = new JCheckBox("Emphysema");
		checkBox27.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox27.setBounds(850, 373, 163, 23);
		tab4.add(checkBox27);
		
		JCheckBox checkBox8 = new JCheckBox("Epilepsy Seizures");
		checkBox8.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox8.setBounds(501, 347, 163, 23);
		tab4.add(checkBox8);
		
		JCheckBox checkBox17 = new JCheckBox("Ulcer Disease");
		checkBox17.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox17.setBounds(677, 347, 163, 23);
		tab4.add(checkBox17);
		
		JCheckBox checkBox26 = new JCheckBox("Lung Disease");
		checkBox26.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox26.setBounds(850, 347, 163, 23);
		tab4.add(checkBox26);
		
		JCheckBox checkBox25 = new JCheckBox("Venereal Disease");
		checkBox25.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox25.setBounds(850, 321, 163, 23);
		tab4.add(checkBox25);
		
		JCheckBox checkBox16 = new JCheckBox("Ulcerative Colitis");
		checkBox16.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox16.setBounds(677, 321, 163, 23);
		tab4.add(checkBox16);
		
		JCheckBox checkBox7 = new JCheckBox("Emotional Disorder");
		checkBox7.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		checkBox7.setBounds(501, 321, 163, 23);
		tab4.add(checkBox7);
		
		JLabel lbl19 = new JLabel("Other illnesses:");
		lbl19.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		lbl19.setBounds(501, 404, 122, 22);
		tab4.add(lbl19);
		
		textFieldOtherIllnesses = new JTextField();
		textFieldOtherIllnesses.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldOtherIllnesses.setColumns(10);
		textFieldOtherIllnesses.setBounds(619, 401, 394, 29);
		tab4.add(textFieldOtherIllnesses);
		
		JLabel lbl20 = new JLabel("Please list any Operations:");
		lbl20.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl20.setBounds(501, 447, 295, 22);
		tab4.add(lbl20);
		
		textFieldOperations = new JTextField();
		textFieldOperations.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldOperations.setColumns(10);
		textFieldOperations.setBounds(501, 477, 512, 29);
		tab4.add(textFieldOperations);
		
		JLabel lbl21 = new JLabel("Please list your Current Medications:");
		lbl21.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl21.setBounds(501, 517, 295, 22);
		tab4.add(lbl21);
		
		textFieldMedications = new JTextField();
		textFieldMedications.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldMedications.setColumns(10);
		textFieldMedications.setBounds(501, 550, 512, 29);
		tab4.add(textFieldMedications);
		
		JButton btnSave2 = new JButton(" Create");
		btnSave2.setIcon(new ImageIcon(dashboard.class.getResource("/images/more.png")));
		btnSave2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String checkID = patientId.getText();
				try {
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+ checkID+"'");
					
					if (!rs.first()) {
						
						String patientId1 = patientId.getText();
						String firstName1 = firstName.getText();
						String lastName1 = lastName.getText();
						String birthDate1 = textFieldDate.getText();
						String gender1 = (String) gender.getSelectedItem();
						String age1 = age.getText();
						String height1 = height.getText();
						String weight1 = weight.getText();
						String email1 = email.getText();
						String reason1 = reason.getText();
						
						String patientId2 = patientId.getText();
						String firstName2 = firstName.getText();
						String lastName2 = lastName.getText();
						String Allergies = textFieldAllergies.getText();
						String OtherIllnesses = textFieldOtherIllnesses.getText();
						String Operations = textFieldOperations.getText();
						String Medications = textFieldMedications.getText();
						
						try {
//							INSERT DATA to EACH COLUMN in DATABASE
							pst = con.prepareStatement("INSERT INTO generalpatientinformation(id, firstname, lastname, birthdate, gender, age, hieght, weight, email, reason)values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
							pst.setString(1, patientId1);
							pst.setString(2, firstName1);
							pst.setString(3, lastName1);
							pst.setString(4, birthDate1);
							pst.setString(5, gender1);
							pst.setString(6, age1);
							pst.setString(7, height1);
							pst.setString(8, weight1);
							pst.setString(9, email1);
							pst.setString(10, reason1);
							
							int k = pst.executeUpdate();
							
							if (k==1) {
								success.main(null);
								patientId.setText("");
								firstName.setText("");
								lastName.setText("");
								textFieldDate.setText("");
								gender.setSelectedItem(0);
								age.setText("");
								height.setText("");
								weight.setText("");
								email.setText("");
								reason.setText("");
								
								FetchGPI();
								displayThisToDiagnosisInfo();
								countForGPI();
							} else {
								error.main(null);
							}
						} catch (SQLException e1) {
							Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e1);
							
						}
						
						try {
//							INSERT DATA to EACH COLUMN
							pst = con.prepareStatement("INSERT INTO patientmedicalhistory(id, firstname, lastname, allergies, illness, operations, currentMedications) values (?, ?, ?, ?, ?, ?, ?)");
							pst.setString(1, patientId2);
							pst.setString(2, firstName2);
							pst.setString(3, lastName2);
							pst.setString(4, Allergies);
							pst.setString(5, OtherIllnesses);
							pst.setString(6, Operations);
							pst.setString(7, Medications);

							int k = pst.executeUpdate();
							
							if (k==1) {
								textFieldAllergies.setText("");
								textFieldOtherIllnesses.setText("");
								textFieldOperations.setText("");
								textFieldMedications.setText("");
								FetchPMH();
							} else {
								error.main(null);
								
							}
						} catch (SQLException e1) {
							Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e1);
						}
						
					} else {
						existed.main(null);
						
					}	
				} catch(Exception e4){	
					error.main(null);
					
				}
				
				
			}
		});
		btnSave2.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnSave2.setBounds(850, 647, 158, 29);
		tab4.add(btnSave2);
		
		JLabel lbl2 = new JLabel("Patient ID:");
		lbl2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl2.setBounds(33, 71, 122, 22);
		tab4.add(lbl2);
		
		patientId = new JTextField();
		patientId.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		patientId.setColumns(10);
		patientId.setBounds(33, 96, 209, 29);
		tab4.add(patientId);
		
		
		
		JLabel lbl11 = new JLabel("Age:");
		lbl11.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl11.setBounds(178, 301, 138, 22);
		tab4.add(lbl11);
		
		age = new JTextField();
		age.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		age.setColumns(10);
		age.setBounds(178, 326, 138, 29);
		tab4.add(age);		
		
		textFieldDate = new JTextField();
		textFieldDate.setForeground(Color.LIGHT_GRAY);
		textFieldDate.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(textFieldDate.getText().equals("yyyy-mm-dd")) {
					textFieldDate.setText("");
					textFieldDate.setForeground(Color.BLACK);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(textFieldDate.getText().equals("")) {
					textFieldDate.setText("yyyy-mm-dd");
					textFieldDate.setForeground(new Color(0xC0C0C0));
				}
			}
		});
		textFieldDate.setText("yyyy-mm-dd");
		textFieldDate.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldDate.setColumns(10);
		textFieldDate.setBounds(33, 245, 209, 29);
		tab4.add(textFieldDate);
		
		JLabel lb16 = new JLabel("Year - Month - Day");
		lb16.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		lb16.setBounds(33, 278, 135, 14);
		tab4.add(lb16);
		JPanel tab5 = new JPanel();
		tab5.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab5, null);
		tab5.setLayout(null);
		
		JLabel lbl23 = new JLabel("Patient ID:");
		lbl23.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl23.setBounds(34, 90, 100, 22);
		tab5.add(lbl23);
		
		textFieldSearch1 = new JTextField();
		textFieldSearch1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				DefaultTableModel table = (DefaultTableModel) GeneralPatientInformationTable.getModel();
				String search = textFieldSearch1.getText().toLowerCase();
				TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
				GeneralPatientInformationTable.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
			}
		});
		
			
			
		textFieldSearch1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldSearch1.setColumns(10);
		textFieldSearch1.setBounds(128, 87, 209, 29);
		tab5.add(textFieldSearch1);
		
		
		
		JButton btnSearch1 = new JButton(" Search ID");
		btnSearch1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel table = (DefaultTableModel) GeneralPatientInformationTable.getModel();
				String search = textFieldSearch1.getText().toLowerCase();
				TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
				GeneralPatientInformationTable.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
				
			}
		});
		btnSearch1.setIcon(new ImageIcon(dashboard.class.getResource("/images/magnifying-glass-search.png")));
		btnSearch1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnSearch1.setBounds(347, 86, 158, 29);
		tab5.add(btnSearch1);
		
		JButton btnDelete1 = new JButton("Delete");
		btnDelete1.setEnabled(false);
		btnDelete1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteInfo1();
			}
		});
		btnDelete1.setIcon(new ImageIcon(dashboard.class.getResource("/images/trash-bin.png")));
		btnDelete1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnDelete1.setBounds(855, 646, 158, 29);
		tab5.add(btnDelete1);
		
		JButton btnUpdate1 = new JButton("Update");
		btnUpdate1.setEnabled(false);
		btnUpdate1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnUpdate1.setBounds(687, 646, 158, 29);
		tab5.add(btnUpdate1);
		
		
		
		
		JButton btnNew1 = new JButton("New");
		btnNew1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(true);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				tabbedPane.setSelectedIndex(3);
			}
		});
		btnNew1.setIcon(new ImageIcon(dashboard.class.getResource("/images/add.png")));
		btnNew1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnNew1.setBounds(855, 87, 158, 29);
		tab5.add(btnNew1);
		
		JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(34, 127, 978, 496);
		tab5.add(scrollPane2);
		
		GeneralPatientInformationTable = new JTable();
		GeneralPatientInformationTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = GeneralPatientInformationTable.getSelectedRow();
				TableModel model = (TableModel) GeneralPatientInformationTable.getModel();
				textFieldSearch1.setText(model.getValueAt(i, 0).toString());
			}
		});
		GeneralPatientInformationTable.setShowVerticalLines(false);
		GeneralPatientInformationTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
			 public void valueChanged(ListSelectionEvent event) {
		
			  //enable button - put it in an EDT to be safe though
				 
				 
				 int row = GeneralPatientInformationTable.getSelectedRow();
				 if (GeneralPatientInformationTable.isRowSelected(row)) {
					 btnDelete1.setEnabled(true);
					 btnUpdate1.setEnabled(true);
				 }
				 else {
					 btnDelete1.setEnabled(false);
					 btnUpdate1.setEnabled(false);
				 }
			 }
			});
		GeneralPatientInformationTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		GeneralPatientInformationTable.setFont(new Font("Euclid Circular A Light", Font.PLAIN, 13));
		GeneralPatientInformationTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Patient ID", "First Name", "Last Name", "Birthdate", "Gender", "Age", "Height", "Weight", "Email Address", "Reasons"
			}
		));
		GeneralPatientInformationTable.getColumnModel().getColumn(0).setPreferredWidth(62);
		GeneralPatientInformationTable.getColumnModel().getColumn(0).setMinWidth(62);
		GeneralPatientInformationTable.getColumnModel().getColumn(1).setPreferredWidth(150);
		GeneralPatientInformationTable.getColumnModel().getColumn(2).setPreferredWidth(150);
		GeneralPatientInformationTable.getColumnModel().getColumn(3).setPreferredWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(3).setMinWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(4).setPreferredWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(4).setMinWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(5).setPreferredWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(5).setMinWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(6).setPreferredWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(6).setMinWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(7).setPreferredWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(7).setMinWidth(100);
		GeneralPatientInformationTable.getColumnModel().getColumn(8).setPreferredWidth(200);
		GeneralPatientInformationTable.getColumnModel().getColumn(8).setMinWidth(200);
		GeneralPatientInformationTable.getColumnModel().getColumn(9).setPreferredWidth(150);
		GeneralPatientInformationTable.getColumnModel().getColumn(9).setMinWidth(150);
		scrollPane2.setViewportView(GeneralPatientInformationTable);
		
		JButton btnPMH1 = new JButton("Patient Medical History");
		btnPMH1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(5);
			}
		});
		btnPMH1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnPMH1.setBackground(Color.WHITE);
		btnPMH1.setBounds(524, 35, 489, 35);
		tab5.add(btnPMH1);
		
		JButton btnGPI1 = new JButton("General Patient Information");
		btnGPI1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnGPI1.setFont(new Font("Euclid Circular B", Font.BOLD, 20));
		btnGPI1.setBounds(34, 35, 490, 35);
		tab5.add(btnGPI1);
		
		JLabel label = new JLabel("New label");
		label.setBounds(128, 96, 46, 14);
		tab5.add(label);
		JPanel tab6 = new JPanel();
		tab6.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab6, null);
		tab6.setLayout(null);
		
		JLabel lbl23_1 = new JLabel("Patient ID:");
		lbl23_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lbl23_1.setBounds(34, 90, 100, 22);
		tab6.add(lbl23_1);
		
		textFieldSearch2 = new JTextField();
		textFieldSearch2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				DefaultTableModel table = (DefaultTableModel) PatientMedicalHistoryTable.getModel();
				String search = textFieldSearch2.getText().toLowerCase();
				TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
				PatientMedicalHistoryTable.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
			}
		});
		textFieldSearch2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldSearch2.setColumns(10);
		textFieldSearch2.setBounds(128, 87, 209, 29);
		tab6.add(textFieldSearch2);
		
		JButton btnSearch2 = new JButton(" Search ID");
		btnSearch2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel table = (DefaultTableModel) PatientMedicalHistoryTable.getModel();
				String search = textFieldSearch2.getText().toLowerCase();
				TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
				PatientMedicalHistoryTable.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
				
			}
		});
		btnSearch2.setIcon(new ImageIcon(dashboard.class.getResource("/images/magnifying-glass-search.png")));
		btnSearch2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnSearch2.setBounds(347, 86, 158, 29);
		tab6.add(btnSearch2);
		
		JButton btnDelete2 = new JButton("Delete");
		btnDelete2.setEnabled(false);
		btnDelete2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteInfo2();
			}
		});
		btnDelete2.setIcon(new ImageIcon(dashboard.class.getResource("/images/trash-bin.png")));
		btnDelete2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnDelete2.setBounds(855, 646, 158, 29);
		tab6.add(btnDelete2);
		
		btnUpdate1.setIcon(new ImageIcon(dashboard.class.getResource("/images/refresh.png")));
		btnUpdate1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(true);
				selector6.setVisible(false);
				selector7.setVisible(false);
				tabbedPane.setSelectedIndex(7);
				
				String id1 = textFieldSearch1.getText();
				textFieldSearch.setText(id1);
				
				try {
					
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+id1+"'");
					if (!rs.first()) {
						doesNotExist.setVisible(true);
						btnUpdate.setEnabled(false);
						textField_1.setEnabled(false);
						textField_2.setEnabled(false);
						textField_3.setEnabled(false);
						textField_4.setEnabled(false);
						textField_5.setEnabled(false);
						textField_6.setEnabled(false);
						textField_7.setEnabled(false);
						textField_8.setEnabled(false);
						textField_13.setEnabled(false);
						textField_14.setEnabled(false);
						textField_15.setEnabled(false);
						textField_16.setEnabled(false);
						
						
					} else {
						doesNotExist.setVisible(false);
						btnUpdate.setEnabled(true);
						textField_1.setEnabled(true);
						textField_2.setEnabled(true);
						textField_3.setEnabled(true);
						textField_4.setEnabled(true);
						textField_5.setEnabled(true);
						textField_6.setEnabled(true);
						textField_7.setEnabled(true);
						textField_8.setEnabled(true);
						textField_13.setEnabled(true);
						textField_13.setEnabled(true);
						textField_14.setEnabled(true);
						textField_15.setEnabled(true);
						textField_16.setEnabled(true);
					}	
				} catch(Exception e4){	
					error.main(null);
					
				}
				try {
					pst = con.prepareStatement("SELECT * FROM generalpatientinformation WHERE id=?");
					pst.setString(1, id1);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_13.setText(rs.getString(5));
						textField_4.setText(rs.getString(6));
						textField_5.setText(rs.getString(7));
						textField_6.setText(rs.getString(8));
						textField_7.setText(rs.getString(9));
						textField_8.setText(rs.getString(10));
		
					} else {
						textField_1.setText(null);
						textField_2.setText(null);
						textField_3.setText(null);
						textField_13.setText(null);
						textField_4.setText(null);
						textField_5.setText(null);
						textField_7.setText(null);
						textField_8.setText(null);
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				try {
					pst = con.prepareStatement("SELECT * FROM patientmedicalhistory WHERE id=?");
					pst.setString(1, id1);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_10.setText(rs.getString(4));
						textField_9.setText(rs.getString(5));
						textField_12.setText(rs.getString(6));
						
						
					} else {
						textField_10.setText(null);
						textField_9.setText(null);
						textField_12.setText(null);
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, id1);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_11.setText(rs.getString(4));
						textField_16.setText(rs.getString(6));
						textField_14.setText(rs.getString(5));
						textField_15.setText(rs.getString(7));
						
					} else {
						textField_11.setText(null);
						textField_16.setText(null);
						textField_14.setText(null);
						textField_15.setText(null);
						
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, id1);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_14.setText(rs.getString(7));
						textField_15.setText(rs.getString(5));
						textField_16.setText(rs.getString(6));
	
					} else {
						textField_14.setText(null);
						textField_15.setText(null);
						textField_16.setText(null);	
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
			}
		});
		
		JButton btnUpdate2 = new JButton("Update");
		 btnUpdate2.setEnabled(false);
		btnUpdate2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(true);
				selector6.setVisible(false);
				selector7.setVisible(false);
				tabbedPane.setSelectedIndex(7);
				
				String id3 = textFieldSearch2.getText();
				textFieldSearch.setText(id3);
				
				try {
					
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+id3+"'");
					if (!rs.first()) {
						doesNotExist.setVisible(true);
						btnUpdate.setEnabled(false);
						textField_1.setEnabled(false);
						textField_2.setEnabled(false);
						textField_3.setEnabled(false);
						textField_4.setEnabled(false);
						textField_5.setEnabled(false);
						textField_6.setEnabled(false);
						textField_7.setEnabled(false);
						textField_8.setEnabled(false);
						textField_13.setEnabled(false);
						textField_14.setEnabled(false);
						textField_15.setEnabled(false);
						textField_16.setEnabled(false);
						
						
					} else {
						doesNotExist.setVisible(false);
						btnUpdate.setEnabled(true);
						textField_1.setEnabled(true);
						textField_2.setEnabled(true);
						textField_3.setEnabled(true);
						textField_4.setEnabled(true);
						textField_5.setEnabled(true);
						textField_6.setEnabled(true);
						textField_7.setEnabled(true);
						textField_8.setEnabled(true);
						textField_13.setEnabled(true);
						textField_13.setEnabled(true);
						textField_14.setEnabled(true);
						textField_15.setEnabled(true);
						textField_16.setEnabled(true);
					}	
				} catch(Exception e4){	
					error.main(null);
					
				}
				try {
					pst = con.prepareStatement("SELECT * FROM generalpatientinformation WHERE id=?");
					pst.setString(1, id3);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_13.setText(rs.getString(5));
						textField_4.setText(rs.getString(6));
						textField_5.setText(rs.getString(7));
						textField_6.setText(rs.getString(8));
						textField_7.setText(rs.getString(9));
						textField_8.setText(rs.getString(10));
		
					} else {
						textField_1.setText(null);
						textField_2.setText(null);
						textField_3.setText(null);
						textField_13.setText(null);
						textField_4.setText(null);
						textField_5.setText(null);
						textField_7.setText(null);
						textField_8.setText(null);
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				try {
					pst = con.prepareStatement("SELECT * FROM patientmedicalhistory WHERE id=?");
					pst.setString(1, id3);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_10.setText(rs.getString(4));
						textField_9.setText(rs.getString(5));
						textField_12.setText(rs.getString(6));
						
						
					} else {
						textField_10.setText(null);
						textField_9.setText(null);
						textField_12.setText(null);
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, id3);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_11.setText(rs.getString(4));
						textField_16.setText(rs.getString(6));
						textField_14.setText(rs.getString(5));
						textField_15.setText(rs.getString(7));
						
					} else {
						textField_11.setText(null);
						textField_16.setText(null);
						textField_14.setText(null);
						textField_15.setText(null);
						
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, id3);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_14.setText(rs.getString(7));
						textField_15.setText(rs.getString(5));
						textField_16.setText(rs.getString(6));
						
						
					} else {
						textField_14.setText(null);
						textField_15.setText(null);
						textField_16.setText(null);
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}		
			}
		});
		
		
		btnUpdate2.setIcon(new ImageIcon(dashboard.class.getResource("/images/refresh.png")));
		btnUpdate2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnUpdate2.setBounds(687, 646, 158, 29);
		tab6.add(btnUpdate2);
		
		JButton btnNew2 = new JButton("New");
		btnNew2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(3);
				selector1.setVisible(false);
				selector2.setVisible(true);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
			}
		});
		btnNew2.setIcon(new ImageIcon(dashboard.class.getResource("/images/add.png")));
		btnNew2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnNew2.setBounds(855, 87, 158, 29);
		tab6.add(btnNew2);
		
		JScrollPane scrollPane3 = new JScrollPane();
		scrollPane3.setBounds(34, 127, 978, 496);
		tab6.add(scrollPane3);
		
		PatientMedicalHistoryTable = new JTable();
		PatientMedicalHistoryTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		PatientMedicalHistoryTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = PatientMedicalHistoryTable.getSelectedRow();
				TableModel model = (TableModel) PatientMedicalHistoryTable.getModel();
				textFieldSearch2.setText(model.getValueAt(i, 0).toString());
			}
		});
		PatientMedicalHistoryTable.setShowVerticalLines(false);
		PatientMedicalHistoryTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
				 public void valueChanged(ListSelectionEvent event) {
				  //enable button - put it in an EDT to be safe though
					 int row = PatientMedicalHistoryTable.getSelectedRow();
					 if (PatientMedicalHistoryTable.isRowSelected(row)) {
						 btnDelete2.setEnabled(true);
						 btnUpdate2.setEnabled(true);
					 }
					 else {
						 btnDelete2.setEnabled(false);
						 btnUpdate2.setEnabled(false);
					 }
				}
			});
		PatientMedicalHistoryTable.setFont(new Font("Euclid Circular A Light", Font.PLAIN, 13));
		PatientMedicalHistoryTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"Patient ID", "First Name", "Last Name", "Allergies", "Illness", "Operations", "Current Medications"
			}
		));
		PatientMedicalHistoryTable.getColumnModel().getColumn(0).setPreferredWidth(62);
		PatientMedicalHistoryTable.getColumnModel().getColumn(0).setMinWidth(62);
		PatientMedicalHistoryTable.getColumnModel().getColumn(1).setPreferredWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(1).setMinWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(2).setPreferredWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(2).setMinWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(3).setPreferredWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(3).setMinWidth(75);
		PatientMedicalHistoryTable.getColumnModel().getColumn(4).setPreferredWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(4).setMinWidth(75);
		PatientMedicalHistoryTable.getColumnModel().getColumn(5).setPreferredWidth(150);
		PatientMedicalHistoryTable.getColumnModel().getColumn(5).setMinWidth(75);
		PatientMedicalHistoryTable.getColumnModel().getColumn(6).setPreferredWidth(170);
		PatientMedicalHistoryTable.getColumnModel().getColumn(6).setMinWidth(110);
		
		scrollPane3.setViewportView(PatientMedicalHistoryTable);
		
		JButton btnPMH2 = new JButton("Patient Medical History");
		btnPMH2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnPMH2.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnPMH2.setBounds(524, 35, 489, 35);
		tab6.add(btnPMH2);
		
		JButton btnGPI2 = new JButton("General Patient Information");
		btnGPI2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(4);
			}
		});
		btnGPI2.setBackground(Color.WHITE);
		btnGPI2.setFont(new Font("Euclid Circular B", Font.BOLD, 20));
		btnGPI2.setBounds(34, 35, 490, 35);
		tab6.add(btnGPI2);
		
		JPanel tab7 = new JPanel();
		tab7.setBackground(Color.WHITE);
		tabbedPane.addTab("New tab", null, tab7, null);
		tab7.setLayout(null);
		
		JLabel lblManageDoctors = new JLabel("Hospital Staff Roles");
		lblManageDoctors.setHorizontalAlignment(SwingConstants.LEFT);
		lblManageDoctors.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		lblManageDoctors.setBackground(Color.WHITE);
		lblManageDoctors.setBounds(33, 27, 244, 36);
		tab7.add(lblManageDoctors);
		
		scrollPane2 = new JScrollPane();
		scrollPane2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane2.setBounds(33, 63, 978, 600);
		tab7.add(scrollPane2);
		
		doctorsTableList = new JTable();
		doctorsTableList.setShowVerticalLines(false);
		doctorsTableList.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Company ID", "First Name", "Last Name", "Email", "Address", "Phone No.", "Designation", "Department"
			}
		));
		doctorsTableList.getColumnModel().getColumn(0).setPreferredWidth(90);
		doctorsTableList.getColumnModel().getColumn(0).setMinWidth(90);
		doctorsTableList.getColumnModel().getColumn(1).setPreferredWidth(150);
		doctorsTableList.getColumnModel().getColumn(1).setMinWidth(150);
		doctorsTableList.getColumnModel().getColumn(2).setPreferredWidth(150);
		doctorsTableList.getColumnModel().getColumn(2).setMinWidth(150);
		doctorsTableList.getColumnModel().getColumn(3).setPreferredWidth(150);
		doctorsTableList.getColumnModel().getColumn(3).setMinWidth(150);
		doctorsTableList.getColumnModel().getColumn(4).setPreferredWidth(160);
		doctorsTableList.getColumnModel().getColumn(4).setMinWidth(160);
		doctorsTableList.getColumnModel().getColumn(5).setPreferredWidth(160);
		doctorsTableList.getColumnModel().getColumn(5).setMinWidth(160);
		doctorsTableList.getColumnModel().getColumn(6).setPreferredWidth(160);
		doctorsTableList.getColumnModel().getColumn(6).setMinWidth(160);
		doctorsTableList.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		doctorsTableList.setBackground(Color.WHITE);
		scrollPane2.setColumnHeaderView(doctorsTableList);
		scrollPane2.setViewportView(doctorsTableList);
		
		JPanel tab8 = new JPanel();
		tabbedPane.addTab("New tab", null, tab8, null);
		tab8.setLayout(null);
		
		JLabel updtLbl1 = new JLabel("Update Patient Information");
		updtLbl1.setHorizontalAlignment(SwingConstants.LEFT);
		updtLbl1.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		updtLbl1.setBackground(Color.WHITE);
		updtLbl1.setBounds(37, 39, 279, 36);
		tab8.add(updtLbl1);
		
		JLabel updtLbl2 = new JLabel("Patient ID:");
		updtLbl2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl2.setBounds(37, 74, 122, 22);
		tab8.add(updtLbl2);
		
		JLabel updtLbl3 = new JLabel("Patient Name:");
		updtLbl3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl3.setBounds(37, 139, 122, 22);
		tab8.add(updtLbl3);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(37, 164, 209, 29);
		tab8.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_2.setColumns(10);
		textField_2.setBounds(256, 164, 209, 29);
		tab8.add(textField_2);
		
		JLabel updtLbl4 = new JLabel("First Name");
		updtLbl4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		updtLbl4.setBounds(37, 196, 122, 14);
		tab8.add(updtLbl4);
		
		JLabel updtLbl5 = new JLabel("Last Name");
		updtLbl5.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		updtLbl5.setBounds(256, 198, 122, 14);
		tab8.add(updtLbl5);
		
		JLabel updtLbl6 = new JLabel("Patient Birthdate:");
		updtLbl6.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl6.setBounds(37, 221, 170, 22);
		tab8.add(updtLbl6);
		
		textField_3 = new JTextField();
		textField_3.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(textField_3.getText().equals("yyyy-mm-dd")) {
					textField_3.setText("");
					textField_3.setForeground(Color.BLACK);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(textField_3.getText().equals("")) {
					textField_3.setText("yyyy-mm-dd");
					textField_3.setForeground(Color.BLACK);
				}
			}
		});
		textField_3.setText("yyyy-mm-dd");
		textField_3.setForeground(Color.BLACK);
		textField_3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_3.setColumns(10);
		textField_3.setBounds(37, 248, 209, 29);
		tab8.add(textField_3);
		
		JLabel updtLbl7 = new JLabel("Year - Month - Day");
		updtLbl7.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 13));
		updtLbl7.setBounds(37, 281, 135, 14);
		tab8.add(updtLbl7);
		
		JLabel updtLbl8 = new JLabel("Patient Gender:");
		updtLbl8.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl8.setBounds(37, 304, 135, 22);
		tab8.add(updtLbl8);
		
		JLabel updtLbl9 = new JLabel("Age:");
		updtLbl9.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl9.setBounds(256, 304, 138, 22);
		tab8.add(updtLbl9);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_4.setColumns(10);
		textField_4.setBounds(256, 329, 209, 29);
		tab8.add(textField_4);
		
		JLabel updtLbl10 = new JLabel("Patient Height (cm's):");
		updtLbl10.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl10.setBounds(37, 372, 181, 22);
		tab8.add(updtLbl10);
		
		JLabel updtLbl11 = new JLabel("Patient Weight (kg's):");
		updtLbl11.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl11.setBounds(256, 372, 181, 22);
		tab8.add(updtLbl11);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_5.setColumns(10);
		textField_5.setBounds(37, 403, 209, 29);
		tab8.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_6.setColumns(10);
		textField_6.setBounds(256, 403, 209, 29);
		tab8.add(textField_6);
		
		JLabel updtLbl12 = new JLabel("Patient E-Mail:");
		updtLbl12.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl12.setBounds(37, 443, 181, 22);
		tab8.add(updtLbl12);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_7.setColumns(10);
		textField_7.setBounds(37, 469, 428, 29);
		tab8.add(textField_7);
		
		JLabel updtLbl13 = new JLabel("Reason for seeing the doctor:");
		updtLbl13.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl13.setBounds(37, 509, 295, 22);
		tab8.add(updtLbl13);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_8.setColumns(10);
		textField_8.setBounds(37, 533, 428, 29);
		tab8.add(textField_8);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textFieldSearch.setColumns(10);
		textFieldSearch.setBounds(37, 99, 209, 29);
		tab8.add(textFieldSearch);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldSearch.getText();
				String firstname =  textField_1.getText();
				String lastname = textField_2.getText();
				String birthdate = textField_3.getText(); 
				String gender = textField_13.getText(); 
				String age = textField_4.getText();
				String height = textField_5.getText(); 
				String weight = textField_6.getText();
				String email = textField_7.getText();
				String reason = textField_8.getText(); 
				String allergies = textField_10.getText(); 
				String illness = textField_9.getText(); 
				String operations = textField_12.getText();
				String medications = textField_11.getText();
				String symptoms = textField_16.getText(); 
				String diagnosis = textField_14 .getText();
				String ward = textField_15 .getText();
				
				try {
					pst = con.prepareStatement("UPDATE generalpatientinformation SET firstname=?, lastname=?, birthdate=?, gender=?, age=?, hieght=?, weight=?, email=?, reason=? WHERE id=?");
					pst.setString(1, firstname);
					pst.setString(2, lastname);
					pst.setString(3, birthdate);
					pst.setString(4, gender);
					pst.setString(5, age);
					pst.setString(6, height);
					pst.setString(7, weight);
					pst.setString(8, email);
					pst.setString(9, reason);
					pst.setString(10, id);
					int k = pst.executeUpdate();
					FetchGPI();
					if(k==1) {
						update.main(null);
						textField_1.setText(null);
						textField_2.setText(null);
						textField_3.setText(null); 
						textField_13.setText(null); 
						textField_4.setText(null);
						textField_5.setText(null); 
						textField_6.setText(null);
						textField_7.setText(null);
						textField_8.setText(null); 
						textFieldSearch.setText(null);
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				try {
					pst = con.prepareStatement("UPDATE patientmedicalhistory SET firstname=?, lastname=?, allergies=?, illness=?, operations=?, currentMedications=? WHERE id=?");
					pst.setString(1, firstname);
					pst.setString(2, lastname);
					pst.setString(3, allergies);
					pst.setString(4, illness);
					pst.setString(5, operations);
					pst.setString(6, medications);
					pst.setString(7, id);
					
					int k = pst.executeUpdate();
					FetchPMH();
					if(k==1) {
						
						textField_10.setText(null);
						textField_9.setText(null);
						textField_12.setText(null); 
						textField_11.setText(null); 
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				try {
					pst = con.prepareStatement("UPDATE diagnosisinformation SET firstname=?, lastname=?, symptoms=?, diagnosis=?, medicines=?, ward=? WHERE id=?");
					pst.setString(1, firstname);
					pst.setString(2, lastname);
					pst.setString(3, symptoms);
					pst.setString(4, diagnosis);
					pst.setString(5, medications);
					pst.setString(6, ward);
					pst.setString(7, id);
					
					int k = pst.executeUpdate();
					displayThisToDiagnosisInfo();
					countForGPI();
					if(k==1) {
						
						textField_11.setText(null);
						textField_16.setText(null);
						textField_14.setText(null); 
						textField_15.setText(null); 
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				
			}
		});
		btnUpdate.setIcon(new ImageIcon(dashboard.class.getResource("/images/refresh.png")));
		btnUpdate.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnUpdate.setBounds(855, 640, 158, 29);
		tab8.add(btnUpdate);

		doesNotExist = new JLabel("Patient ID does not exist.");
		doesNotExist.setForeground(Color.RED);
		doesNotExist.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		doesNotExist.setBounds(125, 74, 209, 22);
		tab8.add(doesNotExist);
		doesNotExist.setVisible(false);
		
		JButton btnSearch3 = new JButton(" Search ID");
		btnSearch3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String srhID =  textFieldSearch.getText();
				try {
					
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM generalpatientinformation WHERE id='"+srhID+"'");
					if (!rs.first()) {
						doesNotExist.setVisible(true);
						btnUpdate.setEnabled(false);
						textField_1.setEnabled(false);
						textField_2.setEnabled(false);
						textField_3.setEnabled(false);
						textField_4.setEnabled(false);
						textField_5.setEnabled(false);
						textField_6.setEnabled(false);
						textField_7.setEnabled(false);
						textField_8.setEnabled(false);
						textField_13.setEnabled(false);
						textField_11.setEnabled(false);
						textField_10.setEnabled(false);
						textField_9.setEnabled(false);
						textField_12.setEnabled(false);
						textField_15.setEnabled(false);
						textField_16.setEnabled(false);
						
						
					} else {
						doesNotExist.setVisible(false);
						btnUpdate.setEnabled(true);
						textField_1.setEnabled(true);
						textField_2.setEnabled(true);
						textField_3.setEnabled(true);
						textField_4.setEnabled(true);
						textField_5.setEnabled(true);
						textField_6.setEnabled(true);
						textField_7.setEnabled(true);
						textField_8.setEnabled(true);
						textField_13.setEnabled(true);
						textField_13.setEnabled(true);
						textField_14.setEnabled(true);
						textField_15.setEnabled(true);
						textField_16.setEnabled(true);
						textField_11.setEnabled(true);
						textField_10.setEnabled(true);
						textField_9.setEnabled(true);
						textField_12.setEnabled(true);
					}	
				} catch(Exception e4){	
					error.main(null);
					
				}
				try {
					pst = con.prepareStatement("SELECT * FROM generalpatientinformation WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_13.setText(rs.getString(5));
						textField_4.setText(rs.getString(6));
						textField_5.setText(rs.getString(7));
						textField_6.setText(rs.getString(8));
						textField_7.setText(rs.getString(9));
						textField_8.setText(rs.getString(10));
		
					} else {
						textField_1.setText(null);
						textField_2.setText(null);
						textField_3.setText(null);
						textField_13.setText(null);
						textField_4.setText(null);
						textField_5.setText(null);
						textField_7.setText(null);
						textField_8.setText(null);
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				try {
					pst = con.prepareStatement("SELECT * FROM patientmedicalhistory WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_10.setText(rs.getString(4));
						textField_9.setText(rs.getString(5));
						textField_12.setText(rs.getString(6));
						
						
					} else {
						textField_10.setText(null);
						textField_9.setText(null);
						textField_12.setText(null);
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_11.setText(rs.getString(4));
						textField_16.setText(rs.getString(6));
						textField_14.setText(rs.getString(5));
						textField_15.setText(rs.getString(7));
						
					} else {
						textField_11.setText(null);
						textField_16.setText(null);
						textField_14.setText(null);
						textField_15.setText(null);
						
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
				
				try {
					pst = con.prepareStatement("SELECT * FROM diagnosisinformation WHERE id=?");
					pst.setString(1, srhID);
					rs = pst.executeQuery();
					if (rs.next() == true) {
						textField_14.setText(rs.getString(7));
						textField_15.setText(rs.getString(5));
						textField_16.setText(rs.getString(6));
						
						
					} else {
						textField_14.setText(null);
						textField_15.setText(null);
						textField_16.setText(null);
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					error.main(null);
				}
			
			}
		});
		btnSearch3.setIcon(new ImageIcon(dashboard.class.getResource("/images/magnifying-glass-search.png")));
		btnSearch3.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		btnSearch3.setBounds(256, 98, 158, 29);
		tab8.add(btnSearch3);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_9.setColumns(10);
		textField_9.setBounds(499, 182, 512, 29);
		tab8.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_10.setColumns(10);
		textField_10.setBounds(499, 109, 512, 29);
		tab8.add(textField_10);
		
		JLabel updtLbl14 = new JLabel("Drug Allergies:");
		updtLbl14.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl14.setBounds(499, 79, 295, 22);
		tab8.add(updtLbl14);
		
		JLabel updtLbl15 = new JLabel("Ilnesses:");
		updtLbl15.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl15.setBounds(499, 149, 295, 22);
		tab8.add(updtLbl15);
		
		textField_11 = new JTextField();
		textField_11.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_11.setColumns(10);
		textField_11.setBounds(499, 329, 512, 29);
		tab8.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_12.setColumns(10);
		textField_12.setBounds(499, 256, 512, 29);
		tab8.add(textField_12);
		
		JLabel updtLbl16 = new JLabel("List of Operations:");
		updtLbl16.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl16.setBounds(499, 226, 295, 22);
		tab8.add(updtLbl16);
		
		JLabel updtLbl17 = new JLabel("List your Current Medications:");
		updtLbl17.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		updtLbl17.setBounds(499, 296, 295, 22);
		tab8.add(updtLbl17);
		
		textField_13 = new JTextField();
		textField_13.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_13.setColumns(10);
		textField_13.setBounds(37, 329, 209, 29);
		tab8.add(textField_13);
		
		textField_16 = new JTextField();
		textField_16.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_16.setColumns(10);
		textField_16.setBounds(499, 402, 512, 29);
		tab8.add(textField_16);
		
		textField_14 = new JTextField();
		textField_14.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_14.setColumns(10);
		textField_14.setBounds(501, 469, 512, 29);
		tab8.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		textField_15.setColumns(10);
		textField_15.setBounds(501, 533, 512, 29);
		tab8.add(textField_15);
		
		JLabel lblSymptoms_1 = new JLabel("Symptoms:");
		lblSymptoms_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblSymptoms_1.setBounds(499, 372, 295, 22);
		tab8.add(lblSymptoms_1);
		
		JLabel lblDiagnosis_1 = new JLabel("Diagnosis:");
		lblDiagnosis_1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblDiagnosis_1.setBounds(499, 443, 295, 22);
		tab8.add(lblDiagnosis_1);
		
		JLabel lblCurrentWard = new JLabel("Current Ward:");
		lblCurrentWard.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 17));
		lblCurrentWard.setBounds(499, 509, 295, 22);
		tab8.add(lblCurrentWard);
		
		
		JButton btnViewProfile = new JButton("View profile");
		btnViewProfile.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnViewProfile.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
				Font font1 = btnViewProfile.getFont();
				Map attributes1 = font1.getAttributes();
				attributes1.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				btnViewProfile.setFont(font1.deriveFont(attributes1));
				btnViewProfile.setForeground(new Color(0xFAAF3B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnViewProfile.setForeground(Color.WHITE);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
			}
		});
		btnViewProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
				
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
				Font font1 = btnViewProfile.getFont();
				Map attributes1 = font1.getAttributes();
				attributes1.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				btnViewProfile.setFont(font1.deriveFont(attributes1));
				btnViewProfile.setForeground(new Color(0xFAAF3B));
				
			}
		});
		btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
		btnViewProfile.setBounds(99, 182, 123, 23);
		btnViewProfile.setForeground(Color.white);
		btnViewProfile.setBorder(null);
		btnViewProfile.setBackground(null);
		btnViewProfile.setOpaque(false);
		btnViewProfile.setBorderPainted(false);
		btnViewProfile.setContentAreaFilled(false);
		btnViewProfile.setFocusPainted(false);
		panel.add(btnViewProfile);
		
		JButton btn3 = new JButton("  Add New Diagnosis Information");
		btn3.setHorizontalAlignment(SwingConstants.LEFT);
		btn3.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon3.png")));
		btn3.setForeground(Color.WHITE);
		btn3.setBackground(new Color(0x1E3C72));
		btn3.setBorder(null);
		//get border of your component which is button as you say
		Border border3 = btn3.getBorder();
		//create a new empty border with name it margin
		Border margin3 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn3.setBorder(new CompoundBorder(border3, margin3));
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(true);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn3.setOpaque(false);
				tabbedPane.setSelectedIndex(1);
				
				
			}
		});
		btn3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn3.setBackground(new Color(0x697DA1));
				btn3.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn3.setBackground(new Color(0x1E3C72));
				btn3.setOpaque(false);
			}
		});
		btn3.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn3.setBounds(0, 363, 327, 51);
		panel.add(btn3);
		
		JButton btn2 = new JButton("  Add New Patient Record");
		btn2.setHorizontalAlignment(SwingConstants.LEFT);
		btn2.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon2.png")));
		btn2.setSelectedIcon(null);
		btn2.setForeground(Color.WHITE);
		btn2.setBorder(null);
		btn2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn2.setBackground(new Color(0x697DA1));
				btn2.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn2.setBackground(new Color(0x1E3C72));
				btn2.setOpaque(false);
			}
		});
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(true);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				tabbedPane.setSelectedIndex(3);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn2.setOpaque(false);
			}
		});
		//get border of your component which is button as you say
		Border border2 = btn2.getBorder();
		//create a new empty border with name it margin
		Border margin2 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn2.setBorder(new CompoundBorder(border2, margin2));
		btn2.setBackground(new Color(0x1E3C72));
		btn2.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn2.setBounds(0, 306, 327, 51);
		panel.add(btn2);
		
		JButton btn1 = new JButton("  Dashboard");
		btn1.setHorizontalAlignment(SwingConstants.LEADING);
		btn1.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon1.png")));
		btn1.setForeground(Color.WHITE);
		btn1.setBackground(new Color(0x1E3C72));
		btn1.setBorder(null);
		//get border of your component which is button as you say
		Border border1 = btn1.getBorder();
		//create a new empty border with name it margin
		Border margin1 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn1.setBorder(new CompoundBorder(border1, margin1));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setBackground(new Color(0x697DA1));
				selector1.setVisible(true);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				tabbedPane.setSelectedIndex(0);
				btn1.setOpaque(false);
			}
		});
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn1.setBackground(new Color(0x697DA1));
				btn1.setOpaque(true);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn1.setBackground(new Color(0x1E3C72));
				btn1.setOpaque(false);
			}
		});
		btn1.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn1.setBounds(0, 250, 327, 51);
		panel.add(btn1);
		
		txtNameHere = new JTextField();
		txtNameHere.setHorizontalAlignment(SwingConstants.CENTER);
		txtNameHere.setEditable(false);
		txtNameHere.setText("HELLO, NAME HERE");
		txtNameHere.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 18));
		txtNameHere.setForeground(Color.WHITE);
		txtNameHere.setBorder(null);
		txtNameHere.setBackground(new Color(0x1E3C72));
		txtNameHere.setBounds(0, 206, 327, 34);
		panel.add(txtNameHere);
		txtNameHere.setColumns(10);
		
		JButton btn6 = new JButton(" Hospital Information");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(true);
				selector7.setVisible(false);
				tabbedPane.setSelectedIndex(6);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn6.setOpaque(false);
			}
		});
		btn6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn6.setBackground(new Color(0x697DA1));
				btn6.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn6.setBackground(new Color(0x1E3C72));
				btn6.setOpaque(false);
			}
		});
		btn6.setHorizontalAlignment(SwingConstants.LEFT);
		btn6.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon4.png")));
		btn6.setForeground(Color.WHITE);
		btn6.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn6.setBorder(null);
		btn6.setBackground(new Color(30, 60, 114));
		btn6.setBounds(0, 534, 327, 51);
		//get border of your component which is button as you say
		Border border6 = btn6.getBorder();
		//create a new empty border with name it margin
		Border margin6 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn6.setBorder(new CompoundBorder(border6, margin6));
		panel.add(btn6);
		
		JButton btn5 = new JButton(" Update patient Information");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(true);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn5.setOpaque(false);
				tabbedPane.setSelectedIndex(7);
			}
		});
		
		btn5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn5.setBackground(new Color(0x697DA1));
				btn5.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn5.setBackground(new Color(0x1E3C72));
				btn5.setOpaque(false);
			}
		});
		btn5.setHorizontalAlignment(SwingConstants.LEFT);
		btn5.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon6.png")));
		btn5.setForeground(Color.WHITE);
		btn5.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn5.setBorder(null);
		btn5.setBackground(new Color(30, 60, 114));
		btn5.setBounds(0, 477, 327, 51);
		//get border of your component which is button as you say
		Border border5 = btn5.getBorder();
		//create a new empty border with name it margin
		Border margin5 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn5.setBorder(new CompoundBorder(border5, margin5));
		panel.add(btn5);

		JButton btn4 = new JButton("All Patients Information");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(true);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn4.setOpaque(false);
				tabbedPane.setSelectedIndex(4);
			}
		});
		btn4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn4.setBackground(new Color(0x697DA1));
				btn4.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn4.setBackground(new Color(0x1E3C72));
				btn4.setOpaque(false);
			}
		});
		btn4.setHorizontalAlignment(SwingConstants.LEFT);
		btn4.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon7.png")));
		btn4.setForeground(Color.WHITE);
		btn4.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn4.setBorder(null);
		btn4.setBackground(new Color(30, 60, 114));
		btn4.setBounds(0, 420, 327, 51);
		//get border of your component which is button as you say
		Border border4 = btn4.getBorder();
		//create a new empty border with name it margin
		Border margin4 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn4.setBorder(new CompoundBorder(border4, margin4));
		panel.add(btn4);
		
		JButton btn7 = new JButton(" Logout");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(true);
				btnViewProfile.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 12));
				btnViewProfile.setForeground(Color.white);
				btn7.setOpaque(false);
				exit.main(null);
			}
		});
		btn7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btn7.setBackground(new Color(0x697DA1));
				btn7.setOpaque(true);
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btn7.setBackground(new Color(0x1E3C72));
				btn7.setOpaque(true);
			}
		});
		btn7.setIcon(new ImageIcon(dashboard.class.getResource("/images/icon8.png")));
		btn7.setHorizontalAlignment(SwingConstants.LEFT);
		btn7.setForeground(Color.WHITE);
		btn7.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 17));
		btn7.setBorder(null);
		btn7.setBackground(new Color(30, 60, 114));
		btn7.setBounds(0, 591, 327, 51);
		//get border of your component which is button as you say
		Border border7 = btn7.getBorder();
		//create a new empty border with name it margin
		Border margin7 = new EmptyBorder(0,10,0,0); //top 0, left 10 , bottom 0, right 0
		btn7.setBorder(new CompoundBorder(border7, margin7));
		panel.add(btn7);
		
		JLabel profileImage = new JLabel("");
		profileImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				tabbedPane.setSelectedIndex(2);
				
				selector1.setVisible(false);
				selector2.setVisible(false);
				selector3.setVisible(false);
				selector4.setVisible(false);
				selector5.setVisible(false);
				selector6.setVisible(false);
				selector7.setVisible(false);
				btnViewProfile.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
				
				
				Font font1 = btnViewProfile.getFont();
				Map attributes1 = font1.getAttributes();
				attributes1.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				btnViewProfile.setFont(font1.deriveFont(attributes1));
				btnViewProfile.setForeground(new Color(0xFAAF3B));
				
			}
		});
		profileImage.setIcon(new ImageIcon(dashboard.class.getResource("/images/profile1.png")));
		profileImage.setBounds(89, 26, 147, 149);
		panel.add(profileImage);
		
		
//		=============================================INDICATORS FOR EACH BUTTONS ========================================
		selector1.setVisible(true);
		selector2.setVisible(false);
		selector3.setVisible(false);
		selector4.setVisible(false);
		selector5.setVisible(false);
		selector6.setVisible(false);
		selector7.setVisible(false);
	}
//	===================================================FETCH DATA FROM DATABASE AND DISPLAY IN TABLE=======================================================
	public void FetchGPI() {
		int q1;
		try {
			pst = con.prepareStatement("SELECT * FROM generalpatientinformation");
			rs = pst.executeQuery();
			ResultSetMetaData rss = rs.getMetaData();
			q1 = rss.getColumnCount();
			DefaultTableModel df1 = (DefaultTableModel) GeneralPatientInformationTable.getModel();
			df1.setRowCount(0);
			while(rs.next()) {
				Vector<String> v2 = new Vector<String>();
				for (int a = 1; a <= q1; a++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("firstname"));
					v2.add(rs.getString("lastname"));
					v2.add(rs.getString("birthdate"));
					v2.add(rs.getString("gender"));
					v2.add(rs.getString("age"));
					v2.add(rs.getString("hieght"));
					v2.add(rs.getString("weight"));
					v2.add(rs.getString("email"));
					v2.add(rs.getString("reason"));
				}
				df1.addRow(v2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e);
			error.main(null);
		}
	}
	
//	=====================================================================FETCH DATA FROM SERVER =========================================
	
	public void FetchPMH() {
		int q1;
		try {
			pst = con.prepareStatement("SELECT * FROM patientmedicalhistory");
			rs = pst.executeQuery();
			ResultSetMetaData rss = rs.getMetaData();
			q1 = rss.getColumnCount();
			DefaultTableModel df2 = (DefaultTableModel) PatientMedicalHistoryTable.getModel();
			df2.setRowCount(0);
			while(rs.next()) {
				Vector<String> v2 = new Vector<String>();
				for (int a = 1; a <= q1; a++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("firstname"));
					v2.add(rs.getString("lastname"));
					v2.add(rs.getString("allergies"));
					v2.add(rs.getString("illness"));
					v2.add(rs.getString("operations"));
					v2.add(rs.getString("currentMedications"));
				}
				df2.addRow(v2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, e);
			error.main(null);
		}
	}
	
	public void displayThisToDiagnosisInfo() {
		int q1;
		try {
			pst = con.prepareStatement("SELECT * FROM generalpatientinformation");
			rs = pst.executeQuery();
			ResultSetMetaData rss = rs.getMetaData();
			q1 = rss.getColumnCount();
			DefaultTableModel df2 = (DefaultTableModel) DiagnosisInfoTable.getModel();
			df2.setRowCount(0);
			while(rs.next()) {
				Vector<String> v2 = new Vector<String>();
				for (int a = 1; a <= q1; a++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("firstname"));
					v2.add(rs.getString("lastname"));
					v2.add(rs.getString("birthdate"));
					v2.add(rs.getString("gender"));
					v2.add(rs.getString("age"));
					v2.add(rs.getString("hieght"));
					v2.add(rs.getString("weight"));
				}
				df2.addRow(v2);
			}
		} catch (SQLException okayRamanKo) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, okayRamanKo);
			error.main(null);
		}
	}
	
	public void FetchHSR() {
		int q1;
		try {
			pst = con.prepareStatement("SELECT * FROM hospitalstaffs");
			rs = pst.executeQuery();
			ResultSetMetaData rss = rs.getMetaData();
			q1 = rss.getColumnCount();
			DefaultTableModel df2 = (DefaultTableModel) doctorsTableList.getModel();
			df2.setRowCount(0);
			while(rs.next()) {
				Vector<String> v2 = new Vector<String>();
				for (int a = 1; a <= q1; a++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("firstname"));
					v2.add(rs.getString("lastname"));
					v2.add(rs.getString("emailaddress"));
					v2.add(rs.getString("residencialaddress"));
					v2.add(rs.getString("phonenumber"));
					v2.add(rs.getString("role"));
					v2.add(rs.getString("department"));
				}
				df2.addRow(v2);
			}
		} catch (SQLException okayRamanKo) {
			// TODO Auto-generated catch block
			Logger.getLogger(dashboard.class.getName()).log(Level.SEVERE, null, okayRamanKo);
			error.main(null);
		}
	}
//	================================================================UPDATE METHOD============================================================

//		DELETE METHOD WITH UPDATE
	public void deleteInfo1() {
		int row = GeneralPatientInformationTable.getSelectedRow();
		
		String cell = (String) GeneralPatientInformationTable.getModel().getValueAt(row, 0);
		int opt = JOptionPane.showConfirmDialog(null,  "Are you sure do you want to delete this item permanently?", "CONFIRM DELETE", JOptionPane.YES_NO_OPTION);
		
		if (opt == 0 ) {
			try {
				pst = con.prepareStatement("DELETE FROM generalpatientinformation WHERE id = " + cell);
				int k = pst.executeUpdate();
				FetchPMH();
				FetchGPI();
				displayThisToDiagnosisInfo();
				countForGPI();
				deleted del = new deleted();
				del.successFrame.setVisible(true);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				error.main(null);
			}
		}
		
	}
	public void deleteInfo2() {
		int row = PatientMedicalHistoryTable.getSelectedRow();
		String cell = (String) PatientMedicalHistoryTable.getModel().getValueAt(row, 0);
		int opt = JOptionPane.showConfirmDialog(null,  "Are you sure do you want to delete this item permanently?", "CONFIRM DELETE", JOptionPane.YES_NO_OPTION);

		if (opt == 0 ) {
		try {
			pst = con.prepareStatement("DELETE FROM patientmedicalhistory WHERE id = " + cell);
			int k = pst.executeUpdate();
			FetchPMH();
			FetchGPI();
			displayThisToDiagnosisInfo();
			countForGPI();
			deleted del = new deleted();
			del.successFrame.setVisible(true);
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			error.main(null);
			}
		}
	}
	
//	DASHBOARD COUNT
	public void countForGPI() {
		try {
			
			String sql = "SELECT count(id) from generalpatientinformation";
			PreparedStatement pst = con.prepareStatement(sql);
			rs= pst.executeQuery();
			if(rs.next()) {
				String total = rs.getString("count(id)");
				totalPatients.setText(total);
				
			}
			
			}catch (Exception e){
				
			}
	}
	
	public void countForHSI() {
		try {
			
			String sql = "SELECT count(id) from hospitalstaffs";
			PreparedStatement pst = con.prepareStatement(sql);
			rs= pst.executeQuery();
			if(rs.next()) {
				String total = rs.getString("count(id)");
				totalHospitalStaff.setText(total);
				
			}
			
			}catch (Exception e){
				
			}
	}
	public static void profileInfo() {
		
	}
}
