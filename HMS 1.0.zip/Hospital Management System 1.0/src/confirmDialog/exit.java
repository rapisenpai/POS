package confirmDialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JRootPane;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.border.MatteBorder;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowEvent;

public class exit {

	private JDialog exitFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					exit window = new exit();
					window.exitFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public exit() {
		initialize();
		centreWindow(exitFrame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		exitFrame = new JDialog();
		exitFrame.addWindowFocusListener(new WindowFocusListener() {
			public void windowGainedFocus(WindowEvent e) {
			}
			public void windowLostFocus(WindowEvent e) {
				exitFrame.setAlwaysOnTop(true);
			}
		});
		exitFrame.setBounds(100, 100, 368, 181);
		exitFrame.setUndecorated(true);
		
		
		
		
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combobox
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
		
		JButton btnExit = new JButton("X");
		btnExit.setBounds(279, 0, 89, 23);
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		
		btnExit.setIcon(null);
		btnExit.setBackground(new Color(0xCD2D2B));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitFrame.dispose();
			}
		});
		exitFrame.getContentPane().setLayout(null);
		exitFrame.getContentPane().add(btnExit);
		exitFrame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		btnExit.setBorderPainted(false); 
		
		JLabel confirmDialog1 = new JLabel("Are you sure do you want to logout");
		confirmDialog1.setHorizontalAlignment(SwingConstants.CENTER);
		confirmDialog1.setForeground(Color.BLACK);
		confirmDialog1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		confirmDialog1.setBackground(Color.WHITE);
		confirmDialog1.setBounds(41, 65, 279, 23);
		exitFrame.getContentPane().add(confirmDialog1);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 368, 181);
		exitFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel confirmDialog2 = new JLabel("and exit application?");
		confirmDialog2.setBounds(89, 89, 188, 19);
		confirmDialog2.setHorizontalAlignment(SwingConstants.CENTER);
		confirmDialog2.setForeground(Color.BLACK);
		confirmDialog2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		confirmDialog2.setBackground(Color.WHITE);
		panel.add(confirmDialog2);
		
		JButton btnYes = new JButton("YES");
		btnYes.setBounds(89, 119, 89, 23);
		panel.add(btnYes);
		btnYes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					System.exit(0);
				
			}
		});
		btnYes.setForeground(Color.WHITE);
		btnYes.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnYes.setBorderPainted(false);
		btnYes.setBackground(new Color(0x4360DF));
		
		JButton btnNo = new JButton("NO");
		btnNo.setBounds(188, 119, 89, 23);
		panel.add(btnNo);
		btnNo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitFrame.dispose();
				
				
			}
		});
		btnNo.setForeground(Color.WHITE);
		btnNo.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnNo.setBorderPainted(false);
		btnNo.setBackground(new Color(205, 45, 43));
		
	}
	

	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
}
