package confirmDialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.JRootPane;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.border.MatteBorder;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowEvent;

public class existed2 {

	private JDialog errorFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					existed2 window = new existed2();
					window.errorFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public existed2() {
		initialize();
		centreWindow(errorFrame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		errorFrame = new JDialog();
		errorFrame.addWindowFocusListener(new WindowFocusListener() {
			public void windowGainedFocus(WindowEvent e) {
			}
			public void windowLostFocus(WindowEvent e) {
				errorFrame.setAlwaysOnTop(true);
			}
		});
		errorFrame.setBounds(100, 100, 368, 181);
		errorFrame.setUndecorated(true);
		
		
		
		
		
		// Removes the dotted border around controls which is not consistent with Windows
        UIManager.put("Button.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToggleButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // ways to remove it from other controls...
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("TabbedPane.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("Slider.focus", new ColorUIResource(new Color(0, 0, 0, 0)));

        // figure out combobox
        UIManager.put("ComboBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
		
		JButton btnExit = new JButton("X");
		btnExit.setBounds(279, 0, 89, 23);
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		
		btnExit.setIcon(null);
		btnExit.setBackground(new Color(0xCD2D2B));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorFrame.dispose();
			}
		});
		errorFrame.getContentPane().setLayout(null);
		errorFrame.getContentPane().add(btnExit);
		errorFrame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		btnExit.setBorderPainted(false); 
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 368, 181);
		errorFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel confirmDialog2 = new JLabel("Do you want to update the information?");
		confirmDialog2.setBounds(0, 86, 368, 19);
		confirmDialog2.setHorizontalAlignment(SwingConstants.CENTER);
		confirmDialog2.setForeground(Color.BLACK);
		confirmDialog2.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		confirmDialog2.setBackground(Color.WHITE);
		panel.add(confirmDialog2);
		
		JButton btnOK = new JButton("NO");
		btnOK.setBounds(193, 116, 89, 23);
		panel.add(btnOK);
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorFrame.dispose();

			}
		});
		btnOK.setForeground(Color.WHITE);
		btnOK.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnOK.setBorderPainted(false);
		btnOK.setBackground(new Color(205, 45, 43));
		
		JLabel confirmDialog1 = new JLabel("Patient Diagnosis Information is already existed.");
		confirmDialog1.setBounds(0, 61, 368, 23);
		panel.add(confirmDialog1);
		confirmDialog1.setHorizontalAlignment(SwingConstants.CENTER);
		confirmDialog1.setForeground(Color.BLACK);
		confirmDialog1.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		confirmDialog1.setBackground(Color.WHITE);
		
		JButton btnyES = new JButton("YES");
		btnyES.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
			}
		});
		btnyES.setForeground(Color.WHITE);
		btnyES.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 15));
		btnyES.setBorderPainted(false);
		btnyES.setBackground(Color.BLUE);
		btnyES.setBounds(94, 116, 89, 23);
		panel.add(btnyES);
		
	}
	

	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
}
