-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost: 3307
-- Generation Time: May 23, 2022 at 01:30 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homwadrafhaellowix`
--

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `work` varchar(30) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`id`, `firstname`, `lastname`, `birthdate`, `work`, `salary`, `phone`, `email`) VALUES
(1, 'Eron', 'Balasbas', '0000-00-00', 'Instructor', 25000, 945627079, 'eronbalasabas@gmail.com'),
(2, 'Rafhael Lowix', 'Homwad', '2001-09-05', 'Graphic Designer', 30000, 951460224, 'homwad.rafhaellowix@gmail.com'),
(3, 'Ana Mae', 'Sumapig', '2003-07-01', 'Virtual Assistant', 10000, 978361357, 'amejoradasumpapig@gmail.com'),
(4, 'Antonio', 'Sumapig', '1914-05-14', 'Manager', 8900, 978361357, 'sumapig@gmail.com'),
(5, 'Pares', 'Alaberas', '1990-05-13', 'Part Time Worker', 2000, 984510824, 'streamingaccent@gmail.com'),
(6, 'Gerald', 'Alegarbes', '2001-12-18', 'Assistant Manager', 60000, 951047408, 'geraldalegrabes@gmail.com'),
(7, 'Catherine', 'Alegrabes', '1983-08-19', 'Graphic Designer', 10000, 930733774, 'cetherinealegarbes@gmail.com'),
(8, 'Marlyn', 'Jayoma', '1980-10-21', 'N/A', 0, 948511348, 'jayomamaarlyn@gmail.com'),
(9, 'Lhorelai', 'Coso', '0000-00-00', 'Jollibee Crew', 8900, 963163112, 'coso@gmail.com'),
(10, 'rapi', 'senpai', '2001-09-05', 'News Reporter', 20000, 927513716, 'rapisenpai@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
