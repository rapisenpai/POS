import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Panel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.print.PrinterException;

import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;

public class pos {

	private JFrame frmPointOfSales;
	private JTable tableProductsSelected;
	private JTextField JTextTotal;
	private JTextField JtextCash;
	private JTextField JTextChange;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pos window = new pos();
					window.frmPointOfSales.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public pos() {
		initialize();
		getTotal();	
		centreWindow(frmPointOfSales);
	}
	
//	==================================================FUNCTIONS========================================================
	
	public void getTotal() {
		double rowsCount = tableProductsSelected.getRowCount();
		double sum = 0;
		for (int i = 0; i < rowsCount; i++) {

//			Get the value of row and calculate the value for total.
			sum = sum + Double.parseDouble(tableProductsSelected.getValueAt(i, 4).toString());	
		}
//		Set the total to JTextField with a variable name of JTextTotal
		JTextTotal.setText(String.format("Php %.2f", sum));
	}
//	==================================================FUNCTIONS========================================================

	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
	/**
	 * Initialize the contents of the frame.
	 */
	int clickCount = 0;
	private int row;
	
	private void initialize() {
		frmPointOfSales = new JFrame();
//		frmPointOfSales.setBounds(100, 100, 450, 300);
		frmPointOfSales.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPointOfSales.setTitle("Point of Sales ");
		frmPointOfSales.setResizable(false);
		frmPointOfSales.setSize(1380, 740);
		
		frmPointOfSales.getContentPane().setLayout(null);
		
//		Title
		JLabel labelTitle = new JLabel("ONLINE SARI-SARI STORE");
		labelTitle.setForeground(new Color(255, 255, 255));
		labelTitle.setBounds(10, 11, 1344, 30);
		labelTitle.setFont(new Font("Uni Sans Heavy CAPS", Font.PLAIN, 24));
		labelTitle.setHorizontalAlignment(SwingConstants.CENTER);
		frmPointOfSales.getContentPane().add(labelTitle);
		
		JPanel containerTitle = new JPanel();
		containerTitle.setBackground(new Color(0x32517D));
		containerTitle.setBounds(10, 4, 1344, 37);
		frmPointOfSales.getContentPane().add(containerTitle);
		
		JPanel containerProductSelected = new JPanel();
		containerProductSelected.setBackground(new Color(192, 192, 192));
		containerProductSelected.setBounds(10, 52, 532, 532);
		frmPointOfSales.getContentPane().add(containerProductSelected);
		containerProductSelected.setLayout(null);
		
		JLabel JLabelProductsSelected = new JLabel("PRODUCTS SELECTED:");
		JLabelProductsSelected.setBounds(10, 11, 501, 14);
		JLabelProductsSelected.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 15));
		JLabelProductsSelected.setHorizontalAlignment(SwingConstants.CENTER);
		containerProductSelected.add(JLabelProductsSelected);
		
		tableProductsSelected = new JTable();
		tableProductsSelected.setBounds(1, 1, 510, 460);
		tableProductsSelected.setColumnSelectionAllowed(false);
		tableProductsSelected.setRowSelectionAllowed(false);
		tableProductsSelected.setCellSelectionEnabled(false);
		tableProductsSelected.setFillsViewportHeight(true);
		tableProductsSelected.setEnabled(true);
		tableProductsSelected.setTableHeader(null);
		tableProductsSelected.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 15));
		tableProductsSelected.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"JTableProductNo", "JTableProductName", "JTableQuantity", "JTablePrice", "JTableTotal"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		containerProductSelected.add(tableProductsSelected);

		
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 34, 512, 24);
		panel.setBackground(new Color(0x32517D));
		containerProductSelected.add(panel);
		panel.setLayout(null);
		
		JLabel label2 = new JLabel("Product Name");
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		label2.setForeground(Color.WHITE);
		label2.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 14));
		label2.setBounds(99, 0, 99, 20);
		panel.add(label2);
		
		JLabel label3 = new JLabel("Quantity");
		label3.setHorizontalAlignment(SwingConstants.CENTER);
		label3.setForeground(Color.WHITE);
		label3.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 14));
		label3.setBounds(199, 0, 99, 20);
		panel.add(label3);
		
		JLabel label4 = new JLabel("Price");
		label4.setHorizontalAlignment(SwingConstants.CENTER);
		label4.setForeground(Color.WHITE);
		label4.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 14));
		label4.setBounds(298, 0, 99, 20);
		panel.add(label4);
		
		JLabel label5 = new JLabel("Total");
		label5.setHorizontalAlignment(SwingConstants.CENTER);
		label5.setForeground(Color.WHITE);
		label5.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 14));
		label5.setBounds(395, 0, 99, 20);
		panel.add(label5);
		
		JLabel label1 = new JLabel("Product No.");
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		label1.setForeground(Color.WHITE);
		label1.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 14));
		label1.setBounds(0, 0, 99, 20);
		panel.add(label1);
		
		JScrollPane scrollPane = new JScrollPane(tableProductsSelected);
		scrollPane.setBounds(10, 57, 512, 462);
		containerProductSelected.add(scrollPane);
		
		
		JPanel containerProductAvailable = new JPanel();
		containerProductAvailable.setBackground(new Color(192, 192, 192));
		containerProductAvailable.setBounds(562, 52, 802, 532);
		frmPointOfSales.getContentPane().add(containerProductAvailable);
		containerProductAvailable.setLayout(null);
		
		JLabel JLabelAvailableProducts = new JLabel("PRODUCTS AVAILABLE:");
		JLabelAvailableProducts.setBounds(10, 11, 793, 15);
		JLabelAvailableProducts.setHorizontalAlignment(SwingConstants.CENTER);
		JLabelAvailableProducts.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		containerProductAvailable.add(JLabelAvailableProducts);
		
		JButton btn1 = new JButton("");
		btn1.setBounds(10, 37, 89, 89);
		btn1.addActionListener(new ActionListener() {
			
		public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 67.00;
				int productNum = 202201;
				String productName = "Rejoice Rich";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		
		btn1.setIcon(new ImageIcon(pos.class.getResource("/images/Rejoice.jpg")));
		btn1.setBackground(new Color(255, 255, 255));
		btn1.setForeground(new Color(255, 255, 255));
		containerProductAvailable.add(btn1);
		
		JButton btn2 = new JButton("");
		btn2.setIcon(new ImageIcon(pos.class.getResource("/images/Safeguard.jpg")));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 20.00;
				int productNum = 202202;
				String productName = "Safeguard";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn2.setBounds(109, 37, 89, 89);
		btn2.setForeground(Color.WHITE);
		btn2.setBackground(Color.WHITE);
		containerProductAvailable.add(btn2);
		
		JButton btn3 = new JButton("");
		btn3.setIcon(new ImageIcon(pos.class.getResource("/images/Palmolive Naturals.jpg")));
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 50.00;
				int productNum = 202203;
				String productName = "Palmolive Hydrating Glow";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn3.setBounds(208, 37, 89, 89);
		btn3.setForeground(Color.WHITE);
		btn3.setBackground(Color.WHITE);
		containerProductAvailable.add(btn3);
		
		JButton btn4 = new JButton("");
		btn4.setIcon(new ImageIcon(pos.class.getResource("/images/Palmolive Men.jpg")));
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 90.00;
				int productNum = 202204;
				String productName = "Palmolive Silky Straight";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn4.setBounds(307, 37, 89, 89);
		btn4.setForeground(Color.WHITE);
		btn4.setBackground(Color.WHITE);
		containerProductAvailable.add(btn4);
		
		JButton btn5 = new JButton("");
		btn5.setIcon(new ImageIcon(pos.class.getResource("/images/Rejoice Smoothness Expert.jpg")));
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 67.00;
				int productNum = 202205;
				String productName = "Rejoice Conditioner";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn5.setBounds(406, 37, 89, 89);
		btn5.setForeground(Color.WHITE);
		btn5.setBackground(Color.WHITE);
		containerProductAvailable.add(btn5);
		
		JButton btn6 = new JButton("");
		btn6.setIcon(new ImageIcon(pos.class.getResource("/images/Tide.jpg")));
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 120.00;
				int productNum = 202206;
				String productName = "Tide";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn6.setBounds(505, 37, 89, 89);
		btn6.setForeground(Color.WHITE);
		btn6.setBackground(Color.WHITE);
		containerProductAvailable.add(btn6);
		
		JButton btn7 = new JButton("");
		btn7.setIcon(new ImageIcon(pos.class.getResource("/images/Silver Swan Soy Sauce.jpg")));
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 8.00;
				int productNum = 202207;
				String productName = "Silver Swan Soy Sauce";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn7.setBounds(604, 37, 89, 89);
		btn7.setForeground(Color.WHITE);
		btn7.setBackground(Color.WHITE);
		containerProductAvailable.add(btn7);
		
		JButton btn8 = new JButton("");
		btn8.setIcon(new ImageIcon(pos.class.getResource("/images/Silver Swan Vinegar.jpg")));
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 8.00;
				int productNum = 202208;
				String productName = "Silver Swan Vinegar";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn8.setBounds(703, 37, 89, 89);
		btn8.setForeground(Color.WHITE);
		btn8.setBackground(Color.WHITE);
		containerProductAvailable.add(btn8);
		
		JButton btn9 = new JButton("");
		btn9.setIcon(new ImageIcon(pos.class.getResource("/images/Baygon.jpg")));
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 16.00;
				int productNum = 202209;
				String productName = "Baygon";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
			
		});
		btn9.setBounds(10, 137, 89, 89);
		btn9.setForeground(Color.WHITE);
		btn9.setBackground(Color.WHITE);
		containerProductAvailable.add(btn9);
		
		JButton btn10 = new JButton("");
		btn10.setIcon(new ImageIcon(pos.class.getResource("/images/Isopropyl Alcohol.jpg")));
		btn10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 45.00;
				int productNum = 202210;
				String productName = "Isopropyl Alcohol";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn10.setBounds(109, 137, 89, 89);
		btn10.setForeground(Color.WHITE);
		btn10.setBackground(Color.WHITE);
		containerProductAvailable.add(btn10);
		
		JButton btn11 = new JButton("");
		btn11.setIcon(new ImageIcon(pos.class.getResource("/images/Saltshaker.jpg")));
		btn11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 10.00;
				int productNum = 202211;
				String productName = "Salt Shaker";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn11.setBounds(208, 137, 89, 89);
		btn11.setForeground(Color.WHITE);
		btn11.setBackground(Color.WHITE);
		containerProductAvailable.add(btn11);
		
		JButton btn12 = new JButton("");
		btn12.setIcon(new ImageIcon(pos.class.getResource("/images/Colgate.jpg")));
		btn12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 120.00;
				int productNum = 202212;
				String productName = "Colgate";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn12.setBounds(307, 137, 89, 89);
		btn12.setForeground(Color.WHITE);
		btn12.setBackground(Color.WHITE);
		containerProductAvailable.add(btn12);
		
		JButton btn13 = new JButton("");
		btn13.setIcon(new ImageIcon(pos.class.getResource("/images/Baygon Insect Killer.jpg")));
		btn13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 430.00;
				int productNum = 202213;
				String productName = "Baygon Spray";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn13.setBounds(406, 137, 89, 89);
		btn13.setForeground(Color.WHITE);
		btn13.setBackground(Color.WHITE);
		containerProductAvailable.add(btn13);
		
		JButton btn14 = new JButton("");
		btn14.setIcon(new ImageIcon(pos.class.getResource("/images/Lucky Me Beef.jpg")));
		btn14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202214;
				String productName = "Lucky Me Beef";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn14.setBounds(505, 137, 89, 89);
		btn14.setForeground(Color.WHITE);
		btn14.setBackground(Color.WHITE);
		containerProductAvailable.add(btn14);
		
		JButton btn15 = new JButton("");
		btn15.setIcon(new ImageIcon(pos.class.getResource("/images/Lucky Me Chicken.jpg")));
		btn15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202215;
				String productName = "Lucky Me Chicken";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn15.setBounds(604, 137, 89, 89);
		btn15.setForeground(Color.WHITE);
		btn15.setBackground(Color.WHITE);
		containerProductAvailable.add(btn15);
		
		JButton btn16 = new JButton("");
		btn16.setIcon(new ImageIcon(pos.class.getResource("/images/Lucky Me Pancit Canton.jpg")));
		btn16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202216;
				String productName = "Lucky Me Pancit Canton";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn16.setBounds(703, 137, 89, 89);
		btn16.setForeground(Color.WHITE);
		btn16.setBackground(Color.WHITE);
		containerProductAvailable.add(btn16);
		
		JButton btn17 = new JButton("");
		btn17.setIcon(new ImageIcon(pos.class.getResource("/images/Beer.jpg")));
		btn17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 95.00;
				int productNum = 202217;
				String productName = "Red Horse Beer";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn17.setBounds(10, 237, 89, 89);
		btn17.setForeground(Color.WHITE);
		btn17.setBackground(Color.WHITE);
		containerProductAvailable.add(btn17);
		
		JButton btn18 = new JButton("");
		btn18.setIcon(new ImageIcon(pos.class.getResource("/images/C2 Apple.jpg")));
		btn18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202218;
				String productName = "C2";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn18.setBounds(109, 237, 89, 89);
		btn18.setForeground(Color.WHITE);
		btn18.setBackground(Color.WHITE);
		containerProductAvailable.add(btn18);
		
		JButton btn19 = new JButton("");
		btn19.setIcon(new ImageIcon(pos.class.getResource("/images/C2 Lemon Green Tea.jpg")));
		btn19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202219;
				String productName = "C2";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn19.setBounds(208, 237, 89, 89);
		btn19.setForeground(Color.WHITE);
		btn19.setBackground(Color.WHITE);
		containerProductAvailable.add(btn19);
		
		JButton btn20 = new JButton("");
		btn20.setIcon(new ImageIcon(pos.class.getResource("/images/C2.jpg")));
		btn20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 25.00;
				int productNum = 202220;
				String productName = "C2";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn20.setBounds(307, 237, 89, 89);
		btn20.setForeground(Color.WHITE);
		btn20.setBackground(Color.WHITE);
		containerProductAvailable.add(btn20);
		
		JButton btn21 = new JButton("");
		btn21.setIcon(new ImageIcon(pos.class.getResource("/images/Coke Regular 1.5.jpg")));
		btn21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 35.00;
				int productNum = 202221;
				String productName = "Coca Cola 1Ltr.";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn21.setBounds(406, 237, 89, 89);
		btn21.setForeground(Color.WHITE);
		btn21.setBackground(Color.WHITE);
		containerProductAvailable.add(btn21);
		
		JButton btn22 = new JButton("");
		btn22.setIcon(new ImageIcon(pos.class.getResource("/images/Royal.jpg")));
		btn22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 15.00;
				int productNum = 202222;
				String productName = "Royal 8oz";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn22.setBounds(505, 237, 89, 89);
		btn22.setForeground(Color.WHITE);
		btn22.setBackground(Color.WHITE);
		containerProductAvailable.add(btn22);
		
		JButton btn23 = new JButton("");
		btn23.setIcon(new ImageIcon(pos.class.getResource("/images/Softdrinks.jpg")));
		btn23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 12.00;
				int productNum = 202223;
				String productName = "Softdrinks";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
			
		});
		btn23.setBounds(604, 237, 89, 89);
		btn23.setForeground(Color.WHITE);
		btn23.setBackground(Color.WHITE);
		containerProductAvailable.add(btn23);
		
		JButton btn24 = new JButton("");
		btn24.setIcon(new ImageIcon(pos.class.getResource("/images/Zest-O.jpg")));
		btn24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 14.00;
				int productNum = 202224;
				String productName = "ZEST-O";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn24.setBounds(703, 237, 89, 89);
		btn24.setForeground(Color.WHITE);
		btn24.setBackground(Color.WHITE);
		containerProductAvailable.add(btn24);
		
		JButton btn25 = new JButton("");
		btn25.setIcon(new ImageIcon(pos.class.getResource("/images/Bihon.jpg")));
		btn25.setBounds(10, 337, 89, 89);
		btn25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 17.00;
				int productNum = 202225;
				String productName = "Bihon";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn25.setForeground(Color.WHITE);
		btn25.setBackground(Color.WHITE);
		containerProductAvailable.add(btn25);
		
		JButton btn26 = new JButton("");
		btn26.setIcon(new ImageIcon(pos.class.getResource("/images/Brown Sugar.jpg")));
		btn26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 40.00;
				int productNum = 202226;
				String productName = "Sugar";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn26.setBounds(109, 337, 89, 89);
		btn26.setForeground(Color.WHITE);
		btn26.setBackground(Color.WHITE);
		containerProductAvailable.add(btn26);
		
		JButton btn27 = new JButton("");
		btn27.setIcon(new ImageIcon(pos.class.getResource("/images/Chippy.jpg")));
		btn27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 7.00;
				int productNum = 202227;
				String productName = "Chippy";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn27.setBounds(208, 337, 89, 89);
		btn27.setForeground(Color.WHITE);
		btn27.setBackground(Color.WHITE);
		containerProductAvailable.add(btn27);
		
		JButton btn28 = new JButton("");
		btn28.setIcon(new ImageIcon(pos.class.getResource("/images/Choco Mucho Dark Choco.jpg")));
		btn28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 9.00;
				int productNum = 202228;
				String productName = "Choco Mucho";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn28.setBounds(307, 337, 89, 89);
		btn28.setForeground(Color.WHITE);
		btn28.setBackground(Color.WHITE);
		containerProductAvailable.add(btn28);
		
		JButton btn29 = new JButton("");
		btn29.setIcon(new ImageIcon(pos.class.getResource("/images/Choco Mucho.jpg")));
		btn29.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 8.00;
				int productNum = 202229;
				String productName = "Choco Mucho";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn29.setBounds(406, 337, 89, 89);
		btn29.setForeground(Color.WHITE);
		btn29.setBackground(Color.WHITE);
		containerProductAvailable.add(btn29);
		
		JButton btn30 = new JButton("");
		btn30.setIcon(new ImageIcon(pos.class.getResource("/images/Fudgee Barr.jpg")));
		btn30.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 10.00;
				int productNum = 202230;
				String productName = "Fudgee Bar";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn30.setBounds(505, 337, 89, 89);
		btn30.setForeground(Color.WHITE);
		btn30.setBackground(Color.WHITE);
		containerProductAvailable.add(btn30);
		
		JButton btn31 = new JButton("");
		btn31.setIcon(new ImageIcon(pos.class.getResource("/images/Piattos Snack Kentang.jpg")));
		btn31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 7.00;
				int productNum = 202231;
				String productName = "Piattos";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn31.setBounds(604, 337, 89, 89);
		btn31.setForeground(Color.WHITE);
		btn31.setBackground(Color.WHITE);
		containerProductAvailable.add(btn31);
		
		JButton btn32 = new JButton("");
		btn32.setIcon(new ImageIcon(pos.class.getResource("/images/Maxx.jpg")));
		btn32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 1.00;
				int productNum = 202232;
				String productName = "Maxx";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn32.setBounds(703, 337, 89, 89);
		btn32.setForeground(Color.WHITE);
		btn32.setBackground(Color.WHITE);
		containerProductAvailable.add(btn32);
		
		JButton btn40 = new JButton("");
		btn40.setIcon(new ImageIcon(pos.class.getResource("/images/Piattos.jpg")));
		btn40.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 13.00;
				int productNum = 202233;
				String productName = "Piattos";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn40.setBounds(109, 435, 89, 89);
		btn40.setForeground(Color.WHITE);
		btn40.setBackground(Color.WHITE);
		containerProductAvailable.add(btn40);
		
		JButton btn34 = new JButton("");
		btn34.setIcon(new ImageIcon(pos.class.getResource("/images/Garlic.jpg")));
		btn34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 60.00;
				int productNum = 202234;
				String productName = "Garlic";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn34.setBounds(208, 435, 89, 89);
		btn34.setForeground(Color.WHITE);
		btn34.setBackground(Color.WHITE);
		containerProductAvailable.add(btn34);
		
		JButton btn35 = new JButton("");
		btn35.setIcon(new ImageIcon(pos.class.getResource("/images/Ginger root.jpg")));
		btn35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 90.00;
				int productNum = 202235;
				String productName = "Ginger";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn35.setBounds(307, 435, 89, 89);
		btn35.setForeground(Color.WHITE);
		btn35.setBackground(Color.WHITE);
		containerProductAvailable.add(btn35);
		
		JButton btn36 = new JButton("");
		btn36.setIcon(new ImageIcon(pos.class.getResource("/images/Kalamansi.jpg")));
		btn36.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 80.00;
				int productNum = 202236;
				String productName = "Lemon";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn36.setBounds(406, 435, 89, 89);
		btn36.setForeground(Color.WHITE);
		btn36.setBackground(Color.WHITE);
		containerProductAvailable.add(btn36);
		
		JButton btn37 = new JButton("");
		btn37.setIcon(new ImageIcon(pos.class.getResource("/images/Onion.jpg")));
		btn37.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 8.00;
				int productNum = 202237;
				String productName = "Onion";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn37.setBounds(505, 435, 89, 89);
		btn37.setForeground(Color.WHITE);
		btn37.setBackground(Color.WHITE);
		containerProductAvailable.add(btn37);
		
		JButton btn38 = new JButton("");
		btn38.setIcon(new ImageIcon(pos.class.getResource("/images/Magic Sarap.jpg")));
		btn38.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 4.00;
				int productNum = 202238;
				String productName = "Magic Sarap";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn38.setBounds(604, 435, 89, 89);
		btn38.setForeground(Color.WHITE);
		btn38.setBackground(Color.WHITE);
		containerProductAvailable.add(btn38);
		
		JButton btn39 = new JButton("");
		btn39.setIcon(new ImageIcon(pos.class.getResource("/images/Purefoods Chicken Nuggets.jpg")));
		btn39.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 250.00;
				int productNum = 202239;
				String productName = "Pure Foods";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn39.setBounds(703, 435, 89, 89);
		btn39.setForeground(Color.WHITE);
		btn39.setBackground(Color.WHITE);
		containerProductAvailable.add(btn39);
		
		JButton btn33 = new JButton("");
		btn33.setIcon(new ImageIcon(pos.class.getResource("/images/Piattos Sour Cream.jpg")));
		btn33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rowData();
			}
			private void rowData() {
				String getQuantity = JOptionPane.showInputDialog(null, "Enter quantity:", "Quantity", JOptionPane.QUESTION_MESSAGE);
				double quantity = Double.parseDouble(getQuantity);
				double priceItem = 15.00;
				int productNum = 202240;
				String productName = "Piattos";
				double total = quantity * priceItem;
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				model.addRow(new Object[] {productNum, productName, String.format(" %.0f", quantity)
						, String.format("Php %.2f", priceItem), total});
				getTotal();
			}
		});
		btn33.setBounds(10, 437, 89, 89);
		btn33.setForeground(Color.WHITE);
		btn33.setBackground(Color.WHITE);
		containerProductAvailable.add(btn33);
		
		JPanel containerPaymentProcess = new JPanel();
		containerPaymentProcess.setBorder(null);
		containerPaymentProcess.setBackground(Color.LIGHT_GRAY);
		containerPaymentProcess.setBounds(93, 595, 1033, 95);
		frmPointOfSales.getContentPane().add(containerPaymentProcess);
		containerPaymentProcess.setLayout(null);
		
		JButton btnPay = new JButton("Pay");
		btnPay.setFocusPainted(false); 
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				double cash = Double.parseDouble(JtextCash.getText());
				double sum = 0;
				double rowsCount = tableProductsSelected.getRowCount();
				for (int i = 0; i < rowsCount; i++) {

//					Get the value of row and calculate the value for total.
					sum = sum + Double.parseDouble(tableProductsSelected.getValueAt(i, 4).toString());	
				}
				double change = (cash - sum);
		
				JOptionPane.showMessageDialog(frmPointOfSales, "TOTAL: Php " + sum + "\nCASH: Php " + cash +
						"\nCHANGE: Php " + change, "Summary" , JOptionPane.PLAIN_MESSAGE);
				
				JtextCash.setText("Input Cash Here");
				JtextCash.setForeground(new Color(0xC0C0C0));
				JTextChange.setText("Php 0.00");
				JTextTotal.setText("Php 0.00");
				DefaultTableModel recordTable = (DefaultTableModel) tableProductsSelected.getModel();
				recordTable.setRowCount(0);
				
				if (clickCount != 0) {
					clickCount = 0;
				}
	
			}
		});
		btnPay.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnPay.setBounds(750, 11, 130, 33);
		containerPaymentProcess.add(btnPay);
		btnPay.setForeground(new Color(0, 0, 0));
		btnPay.setBackground(Color.WHITE);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setFocusPainted(false); 
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					boolean print = tableProductsSelected.print();
					if (!print) {
						JOptionPane.showMessageDialog(frmPointOfSales, "Unable to Print!", "Message" , JOptionPane.ERROR_MESSAGE);
						
					}
					
				}catch (PrinterException ex) {
					JOptionPane.showConfirmDialog(null, ex.getMessage());
					ex.printStackTrace();
				}
			}
		});
		btnPrint.setForeground(Color.BLACK);
		btnPrint.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnPrint.setBackground(Color.WHITE);
		btnPrint.setBounds(750, 55, 130, 33);
		containerPaymentProcess.add(btnPrint);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.setFocusPainted(false); 
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model = (DefaultTableModel) tableProductsSelected.getModel();
				
				int removeItem = tableProductsSelected.getSelectedRow();
				
				if (removeItem >= 0) {
					model.removeRow(removeItem);
				}
				
				getTotal();
				
				if (clickCount != 0) {
					clickCount = 0;
				}
				
			}
			
		});
		btnRemove.setForeground(Color.BLACK);
		btnRemove.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnRemove.setBackground(Color.WHITE);
		btnRemove.setBounds(892, 55, 130, 33);
		containerPaymentProcess.add(btnRemove);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setFocusPainted(false); 
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JtextCash.setText("Input Cash Here");
				JtextCash.setForeground(new Color(0xC0C0C0));
				JTextChange.setText("Php 0.00");
				JTextTotal.setText("Php 0.00");
				DefaultTableModel recordTable = (DefaultTableModel) tableProductsSelected.getModel();
				recordTable.setRowCount(0);
				
				if (clickCount != 0) {
					clickCount = 0;
				}
				
			}
		});
		btnReset.setForeground(Color.BLACK);
		btnReset.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnReset.setBackground(Color.WHITE);
		btnReset.setBounds(892, 11, 130, 33);
		containerPaymentProcess.add(btnReset);
		
		JButton btnChange = new JButton("Change");
		btnChange.setFocusPainted(false); 
		btnChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				double cash = Double.parseDouble(JtextCash.getText());
				double sum = 0;
				double rowsCount = tableProductsSelected.getRowCount();
				for (int i = 0; i < rowsCount; i++) {

//					Get the value of row and calculate the value for total.
					sum = sum + Double.parseDouble(tableProductsSelected.getValueAt(i, 4).toString());	
				}
				double change = (cash - sum);
				JTextChange.setText(String.format("Php %.2f", change));
				
			}
		});
		btnChange.setForeground(Color.BLACK);
		btnChange.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnChange.setBackground(Color.WHITE);
		btnChange.setBounds(349, 55, 130, 33);
		containerPaymentProcess.add(btnChange);
		
		JTextTotal = new JTextField();
		JTextTotal.setEditable(false);
		JTextTotal.setText("Php 0.00");
		JTextTotal.setFont(new Font("Euclid Circular B SemiBold", Font.PLAIN, 20));
		JTextTotal.setBounds(146, 11, 193, 33);
		containerPaymentProcess.add(JTextTotal);
		JTextTotal.setColumns(10);
		
		
		JtextCash = new JTextField();
		JtextCash.setDisabledTextColor(new Color(0xC0C0C0));
		JtextCash.setText("Input Cash Here");
		JtextCash.setForeground(new Color(0xC0C0C0));
		JtextCash.addFocusListener(new FocusAdapter() {
			
			@Override
			public void focusGained(FocusEvent e) {

				if (JtextCash.getText().equalsIgnoreCase("Input Cash Here")) {
					JtextCash.setText("");
					JtextCash.setForeground(new Color(0x00000));
				}
			}
			@Override
			public void focusLost(FocusEvent e) {

				if (JtextCash.getText().equalsIgnoreCase("")) {
					JtextCash.setText("Input Cash Here");
					JtextCash.setForeground(new Color(0xC0C0C0));
				}
			}
			
		});
		JtextCash.setForeground(Color.GRAY);
		JtextCash.setFont(new Font("Euclid Circular B Medium", Font.PLAIN, 20));
		JtextCash.setColumns(10);
		JtextCash.setBounds(489, 11, 193, 33);
		containerPaymentProcess.add(JtextCash);
		
		
		
		
		JTextChange = new JTextField();
		JTextChange.setEditable(false);
		JTextChange.setText("Php 0.00");
		JTextChange.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		JTextChange.setColumns(10);
		JTextChange.setBounds(489, 55, 193, 33);
		containerPaymentProcess.add(JTextChange);
		
		JComboBox comboBoxPaymentMethod = new JComboBox();
		comboBoxPaymentMethod.setModel(new DefaultComboBoxModel(new String[] {"Cash", "Gcash", "PayPal", "Visa Card"}));
		comboBoxPaymentMethod.setFont(new Font("Euclid Circular A Medium", Font.PLAIN, 20));
		comboBoxPaymentMethod.setBounds(192, 55, 147, 33);
		containerPaymentProcess.add(comboBoxPaymentMethod);
		
		
		JLabel JLabelPaymentMethod = new JLabel("Payment Method:");
		JLabelPaymentMethod.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		JLabelPaymentMethod.setForeground(new Color(0, 0, 0));
		JLabelPaymentMethod.setBounds(10, 55, 180, 33);
		containerPaymentProcess.add(JLabelPaymentMethod);
		
		JLabel JLabelTotal = new JLabel("Total:");
		JLabelTotal.setForeground(Color.BLACK);
		JLabelTotal.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		JLabelTotal.setBounds(10, 11, 126, 33);
		containerPaymentProcess.add(JLabelTotal);
		
		JLabel JLabelCash = new JLabel("Cash:");
		JLabelCash.setForeground(Color.BLACK);
		JLabelCash.setFont(new Font("Euclid Circular A SemiBold", Font.PLAIN, 20));
		JLabelCash.setBounds(349, 11, 84, 33);
		containerPaymentProcess.add(JLabelCash);
		
		JButton btnClear = new JButton("");
		btnClear.setToolTipText("Do you want to clear?");
		btnClear.setBorderPainted(false); 
		btnClear.setContentAreaFilled(true); 
		btnClear.setFocusPainted(true); 
		btnClear.setOpaque(true);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JtextCash.setText("Input Cash Here");
				JtextCash.setForeground(new Color(0xC0C0C0));
			}
		});
		btnClear.setIcon(new ImageIcon(pos.class.getResource("/images/clearIcon.png")));
		btnClear.setForeground(Color.LIGHT_GRAY);
		btnClear.setFont(new Font("Ubuntu", Font.BOLD, 15));
		btnClear.setBackground(Color.LIGHT_GRAY);
		btnClear.setBounds(449, 11, 30, 30);
		containerPaymentProcess.add(btnClear);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.setFocusPainted(false);
//		btnExit.addActionListener(e -> System.exit(0));
		
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			
			}
		});
		btnExit.setBounds(1224, 657, 130, 33);
		frmPointOfSales.getContentPane().add(btnExit);
		btnExit.setForeground(new Color(178, 34, 34));
		btnExit.setFont(new Font("Euclid Circular A SemiBold", Font.BOLD, 20));
		btnExit.setBackground(new Color(255, 255, 255));
		
	}
}
